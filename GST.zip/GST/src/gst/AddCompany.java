package gst;


import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import javax.swing.JLayeredPane;
import javax.swing.border.LineBorder;
import javax.swing.text.BadLocationException;
import javax.swing.text.MaskFormatter;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JFormattedTextField;

public class AddCompany  {
	private static JTextField t2;
	private static JTextField t3;
	private static JTextField t4;
	private static JTextField t6;
	private static JTextField t7;
	private static JTextField t8;
	private static JTextField t9;
	private static JTextField t10;
	private static JTextField t11;
	private static JTextField t12;
	private static JTextField t13;
	private static JTextField t14;
	private static JTextField t15;
	private static JTextField t16;
	static Connection con =null;
	static Statement ps = null;
	static ResultSet rs =null;
	static PreparedStatement st = null;
	
		
	
	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws BadLocationException, ParseException, SQLException {
	
		
		
		 
		final JTextField t1;

		final JFrame iff = new JFrame("Company Details");
		iff.getContentPane().setBackground(new Color(240, 230, 140));
		iff.setResizable(false);
		iff.setBounds(204,31,973,700);
	iff.getContentPane().setLayout(null);
	iff.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	iff.setUndecorated(true);
    
	
	String ms[]={"M/s.","Shree.","Dr.","Er."};
	@SuppressWarnings({ "rawtypes" })
	final JComboBox comboBox = new JComboBox(ms);
	comboBox.setBounds(146, 95, 71, 37);
	iff.getContentPane().add(comboBox);
	
		t1 = new JTextField();
		t1.setBounds(221, 95, 702, 37);
		iff.getContentPane().add(t1);
		t1.setColumns(10);
		JLabel lblCompanyName = new JLabel("Company Name");
		lblCompanyName.setFont(new Font("SansSerif", Font.PLAIN, 15));
		lblCompanyName.setBounds(10, 95, 133, 37);
		iff.getContentPane().add(lblCompanyName);
		
		
		t2 = new JTextField();
		t2.setBounds(146, 143, 777, 37);
		iff.getContentPane().add(t2);
		t2.setColumns(10);
		
		JLabel lblTradeName = new JLabel("Trade Name");
		lblTradeName.setFont(new Font("SansSerif", Font.PLAIN, 15));
		lblTradeName.setBounds(10, 143, 133, 37);
		iff.getContentPane().add(lblTradeName);
		
		JLabel lblContactDetails = new JLabel("Contact Details");
		lblContactDetails.setForeground(Color.BLUE);
		lblContactDetails.setFont(new Font("SansSerif", Font.PLAIN, 19));
		lblContactDetails.setBounds(55, 209, 142, 26);
		iff.getContentPane().add(lblContactDetails);
		
		JLayeredPane layeredPane = new JLayeredPane();
		layeredPane.setBorder(new LineBorder(Color.DARK_GRAY));
		layeredPane.setBounds(10, 426, 401, -324);
		iff.getContentPane().add(layeredPane);
		
		t3 = new JTextField();
		t3.setBounds(160, 276, 273, 26);
		iff.getContentPane().add(t3);
		t3.setColumns(10);
		
		JLabel lblAddress = new JLabel("Address Line 1");
		lblAddress.setFont(new Font("SansSerif", Font.PLAIN, 15));
		lblAddress.setBounds(24, 276, 125, 22);
		iff.getContentPane().add(lblAddress);
		
		JLabel lblAddressLine = new JLabel("Address Line 2");
		lblAddressLine.setFont(new Font("SansSerif", Font.PLAIN, 15));
		lblAddressLine.setBounds(24, 309, 125, 22);
		iff.getContentPane().add(lblAddressLine);
		
		t4 = new JTextField();
		t4.setColumns(10);
		t4.setBounds(160, 306, 273, 26);
		iff.getContentPane().add(t4);
		
		JLabel lblState = new JLabel("State");
		lblState.setFont(new Font("SansSerif", Font.PLAIN, 15));
		lblState.setBounds(24, 343, 125, 20);
		iff.getContentPane().add(lblState);
		
		t6 = new JTextField();
		t6.setBounds(160, 371, 124, 26);
		iff.getContentPane().add(t6);
		t6.setColumns(10);
		
		JLabel lblPlace = new JLabel("Place");
		lblPlace.setFont(new Font("SansSerif", Font.PLAIN, 15));
		lblPlace.setBounds(24, 374, 125, 26);
		iff.getContentPane().add(lblPlace);
		
		final JLabel lblPin = new JLabel("Pin");
		lblPin.setFont(new Font("SansSerif", Font.PLAIN, 15));
		lblPin.setBounds(312, 374, 28, 14);
		iff.getContentPane().add(lblPin);
		
		t7 = new JTextField();
		t7.setBounds(347, 371, 86, 26);
		iff.getContentPane().add(t7);
		t7.setColumns(10);
		
		JLabel lblEmailId = new JLabel("Email ID");
		lblEmailId.setFont(new Font("SansSerif", Font.PLAIN, 15));
		lblEmailId.setBounds(24, 399, 125, 37);
		iff.getContentPane().add(lblEmailId);
		
		JLabel lblWebsite = new JLabel("Website");
		lblWebsite.setFont(new Font("SansSerif", Font.PLAIN, 15));
		lblWebsite.setBounds(24, 437, 125, 35);
		iff.getContentPane().add(lblWebsite);
		
		JLabel lblMobileno = new JLabel("Mobile No.");
		lblMobileno.setFont(new Font("SansSerif", Font.PLAIN, 15));
		lblMobileno.setBounds(24, 483, 125, 23);
		iff.getContentPane().add(lblMobileno);
		
		t8 = new JTextField();
		t8.setColumns(10);
		t8.setBounds(160, 404, 273, 31);
		iff.getContentPane().add(t8);
		
		t9 = new JTextField();
		t9.setColumns(10);
		t9.setBounds(160, 443, 273, 26);
		iff.getContentPane().add(t9);
		
		t10 = new JTextField();
		t10.setColumns(10);
		t10.setBounds(160, 480, 273, 26);
		iff.getContentPane().add(t10);
		
		JLabel lblOtherDetails = new JLabel("Other Details");
		lblOtherDetails.setFont(new Font("SansSerif", Font.PLAIN, 18));
		lblOtherDetails.setForeground(Color.BLUE);
		lblOtherDetails.setBounds(495, 214, 114, 19);
		iff.getContentPane().add(lblOtherDetails);
		
		JLabel lblEstablishmentDate = new JLabel("Establishment Date");
		lblEstablishmentDate.setFont(new Font("SansSerif", Font.PLAIN, 15));
		lblEstablishmentDate.setBounds(467, 287, 142, 21);
		iff.getContentPane().add(lblEstablishmentDate);
		
		t11 = new JTextField();
		t11.setBounds(605, 282, 114, 26);
		iff.getContentPane().add(t11);
		t11.setColumns(10);
		
		JLabel lblGstNumber = new JLabel("GST Number");
		lblGstNumber.setFont(new Font("SansSerif", Font.PLAIN, 15));
		lblGstNumber.setBounds(467, 312, 103, 19);
		iff.getContentPane().add(lblGstNumber);
		
		t12 = new JTextField();
		t12.setColumns(10);
		t12.setBounds(605, 341, 114, 26);
		iff.getContentPane().add(t12);
		
		JLabel lblGstDate = new JLabel("GST Date");
		lblGstDate.setFont(new Font("SansSerif", Font.PLAIN, 15));
		lblGstDate.setBounds(467, 340, 76, 22);
		iff.getContentPane().add(lblGstDate);
		
		String gstcate[]={"Regular","Composition","Non-Resident","Input Service Distributor"};
		
		@SuppressWarnings({ "rawtypes" })
		final JComboBox comboBox_1 = new JComboBox(gstcate);
		comboBox_1.setBounds(605, 370, 159, 26);
		iff.getContentPane().add(comboBox_1);
		
		JLabel lblGstCategory = new JLabel("GST Category");
		lblGstCategory.setFont(new Font("SansSerif", Font.PLAIN, 15));
		lblGstCategory.setBounds(467, 371, 103, 25);
		iff.getContentPane().add(lblGstCategory);
		
		t13 = new JTextField();
		t13.setBounds(605, 401, 93, 26);
		iff.getContentPane().add(t13);
		t13.setColumns(10);
		
		JLabel lblPan = new JLabel("PAN");
		lblPan.setFont(new Font("SansSerif", Font.PLAIN, 15));
		lblPan.setBounds(467, 402, 46, 22);
		iff.getContentPane().add(lblPan);
		
		t14 = new JTextField();
		t14.setColumns(10);
		t14.setBounds(811, 398, 93, 27);
		iff.getContentPane().add(t14);
		
		JLabel lblNewLabel = new JLabel("PAN Date");
		lblNewLabel.setFont(new Font("SansSerif", Font.PLAIN, 15));
		lblNewLabel.setBounds(726, 401, 86, 21);
		iff.getContentPane().add(lblNewLabel);
		
		t15 = new JTextField();
		t15.setColumns(10);
		t15.setBounds(605, 434, 93, 27);
		iff.getContentPane().add(t15);
		
		t16 = new JTextField();
		t16.setColumns(10);
		t16.setBounds(811, 434, 93, 27);
		iff.getContentPane().add(t16);
		
		
		
		JLabel lblTan = new JLabel("TAN");
		lblTan.setFont(new Font("SansSerif", Font.PLAIN, 15));
		lblTan.setBounds(467, 432, 46, 29);
		iff.getContentPane().add(lblTan);
		
		JLabel lblTanDate = new JLabel("TAN Date");
		lblTanDate.setFont(new Font("SansSerif", Font.PLAIN, 15));
		lblTanDate.setBounds(726, 431, 86, 30);
		iff.getContentPane().add(lblTanDate);
		
		@SuppressWarnings("rawtypes")
		final JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setBounds(160, 342, 124, 26);
		iff.getContentPane().add(comboBox_2);
		
		JButton btnClose = new JButton("Close");
		btnClose.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode()==KeyEvent.VK_ESCAPE){
					iff.dispose();
				}
			}
		});
		
		btnClose.setBackground(Color.RED);
		btnClose.setBounds(769, 570, 89, 23);
		iff.getContentPane().add(btnClose);
		

		MaskFormatter mask = new MaskFormatter("##?????####?#?A");
	
    final JFormattedTextField t17 = new JFormattedTextField(mask);
	t17.setBounds(605, 312, 114, 26);
	iff.getContentPane().add(t17);
		
		JButton btnClear = new JButton("Clear");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				t1.setText(" ");
				t2.setText(" ");
				t3.setText(" ");
				t4.setText(" ");
				
				t6.setText(" ");
				t7.setText(" ");
				t8.setText(" ");
				t9.setText(" ");
				t10.setText(" ");
				t11.setText(" ");
				t12.setText(" ");
				t13.setText(" ");
				t14.setText(" ");
				t15.setText(" ");
				t16.setText(" ");
				t17.setText(" ");
				
				
			}
		});
		btnClear.setBackground(Color.ORANGE);
		btnClear.setBounds(668, 570, 89, 23);
		iff.getContentPane().add(btnClear);
		
		

 String sta ="select * from states";
		con = DriverManager.getConnection("jdbc:h2:C:/SimpleGST/GST","sa","");
		 ps = con.createStatement();
		 rs = ps.executeQuery(sta);
		while(rs.next()){
			comboBox_2.addItem(rs.getString("states"));
		}
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try {
					String gstcat = comboBox_1.getSelectedItem().toString();
					String state = comboBox_2.getSelectedItem().toString();
					String t = comboBox.getSelectedItem().toString();
					String cname = t1.getText();
					String tc = t+" "+cname;
					String trade = t2.getText();
					String add1 = t3.getText();
					String add2 = t4.getText();
					String Place = t6.getText();
					String pin = t7.getText();
					String email = t8.getText();
					String website = t9.getText();
					String mob = t10.getText();
					String estd = t11.getText();
					String gst_no = t17.getText();
					String gst_date = t12.getText();
					String pan =t13.getText();
					String pan_date = t14.getText();
					String tan =t15.getText();
					String tan_date = t16.getText();
					
				
					 con=DriverManager.getConnection("jdbc:h2:C:/SimpleGST/GST","sa","");
					
					 st = con.prepareStatement("insert into company values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
					
					st.setString(1,tc );
					st.setString(2,trade );
					st.setString(3,add1 );
					st.setString(4,add2 );
					st.setString(5,Place );
					st.setString(6,state );
					st.setString(7,pin );
					st.setString(8,email );
					st.setString(9,website );
					st.setString(10,mob );
					st.setString(11,estd );
					st.setString(12,gst_no );
					st.setString(13,gst_date );
					st.setString(14,gstcat );
					st.setString(15,pan );
					st.setString(16,pan_date );
					st.setString(17,tan );
					st.setString(18,tan_date );
					
					
					st.execute();
					
					
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}finally {
					try {
						con.close();
					}catch(Exception e) {
					
						e.printStackTrace();
					}
				}
				t1.setText(" ");
				t2.setText(" ");
				t3.setText(" ");
				t4.setText(" ");
				
				t6.setText(" ");
				t7.setText(" ");
				t8.setText(" ");
				t9.setText(" ");
				t10.setText(" ");
				t11.setText(" ");
				t12.setText(" ");
				t13.setText(" ");
				t14.setText(" ");
				t15.setText(" ");
				t16.setText(" ");
				t17.setText(" ");
				
			}
		});
		btnSave.setBackground(Color.GREEN);
		btnSave.setBounds(560, 570, 89, 23);
		iff.getContentPane().add(btnSave);
		
		JButton button = new JButton("");
		button.setBorder(null);
		button.addKeyListener(new KeyAdapter() {
			@Override
				public void keyPressed(KeyEvent e) {
					if(e.getKeyCode()==KeyEvent.VK_ESCAPE){
						iff.dispose();
					}
				}
			});
		button.setContentAreaFilled(false);
		button.setOpaque(false);
		button.setBounds(874, 0, 89, 23);
		iff.getContentPane().add(button);
		
		
		
        
		
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				iff.dispose();
			}
		});

		
		iff.setVisible(true);
	}
	}

