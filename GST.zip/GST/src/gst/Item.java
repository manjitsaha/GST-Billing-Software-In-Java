package gst;


import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JTextArea;
import javax.swing.JButton;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.Color;
import javax.swing.JScrollPane;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * @author manjit
 *
 */
public class Item {

	static JFrame jf = new JFrame("Add Item");
	private static JTextField itemname;
	private static JTextField sac;
	private static JTextField salerate;
	private static JTextField purchaserate;
	private static JTextField cessrate;
	private static JTextField stock;
	private static JTable table;
	private static JTextField deletebox;
	private static JTextField unit;
	static Connection con= null;
	private static JTextField mfgtext;
	
	
	
	
		public static void itemlist() {
			 ResultSet rs = null;
				PreparedStatement st = null;
				
					try {
						con = DriverManager.getConnection("jdbc:h2:C:/SimpleGST/GST","sa","");
						String h = "SELECT * FROM ADDITEMS ORDER BY ITEM_NAME ASC";
						st = con.prepareStatement(h);
						rs = st.executeQuery();
						
			//			while(rs.next()){
						table.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
	          //             }
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
	           	}
	
		
		
	public static void main(String[] args) throws SQLException  {
		jf.getContentPane().setLayout(null);
		jf.getContentPane().setBackground(new Color(240, 230, 140));
		jf.setUndecorated(true);
		jf.requestFocusInWindow();
		
		
		
		
		itemname = new JTextField();
		itemname.setOpaque(false);
		itemname.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent arg0) {
				
				itemname.setOpaque(true);	
				itemname.setBackground(Color.black);
				itemname.setForeground(Color.WHITE);
				
			}
			@Override
			public void focusLost(FocusEvent arg0) {
			
				itemname.setBackground(new Color(240, 230, 140));	
				itemname.setForeground(Color.black);
				
			}
		});
		itemname.setBorder(null);
		itemname.setBounds(136, 70, 522, 28);
		itemname.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				 if(e.getKeyCode()==KeyEvent.VK_ENTER){
	            	 sac.requestFocus();
	             }else if(e.getKeyCode()==KeyEvent.VK_ESCAPE){
	            	 jf.dispose();
	             }
			}
		});
		
		JLabel lblItemName = new JLabel("Item Name ");
		lblItemName.setBounds(33, 70, 81, 21);
		lblItemName.setFont(new Font("Tahoma", Font.PLAIN, 15));
		jf.getContentPane().add(lblItemName);
		jf.getContentPane().add(itemname);
		itemname.setColumns(10);
		
		JLabel lblSachsn = new JLabel("SAC/HSN");
		lblSachsn.setBounds(701, 76, 71, 20);
		lblSachsn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		jf.getContentPane().add(lblSachsn);
		
		
		 unit = new JTextField();
		 unit.setOpaque(false);
			unit.setBorder(null);
		unit.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent arg0) {
				unit.setOpaque(true);
				unit.setBackground(Color.black);
				unit.setForeground(Color.white);
			}
			@Override
			public void focusLost(FocusEvent arg0) {
				unit.setBackground(new Color(240, 230, 140));
				unit.setForeground(Color.black);
			}
		});
		
		
		sac = new JTextField();
		sac.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent arg0) {
				
				sac.setOpaque(true);	
				sac.setBackground(Color.black);
				sac.setForeground(Color.white);
				
			}
			@Override
			public void focusLost(FocusEvent arg0) {
				
				sac.setBackground(new Color(240, 230, 140));
				sac.setForeground(Color.black);
				
			}
		});
		sac.setOpaque(false);
		sac.setBorder(null);
		sac.setBounds(816, 74, 124, 28);
		sac.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode()==KeyEvent.VK_ENTER){
					unit.requestFocus();
				}else if(e.getKeyCode()==KeyEvent.VK_ESCAPE){
	            	 jf.dispose();
	             }
			}
		});
		jf.getContentPane().add(sac);
		sac.setColumns(10);
		
		
		JLabel lblUnit = new JLabel("Unit");
		lblUnit.setBounds(33, 121, 32, 21);
		lblUnit.setFont(new Font("Tahoma", Font.PLAIN, 15));
		jf.getContentPane().add(lblUnit);
		
		JLabel lblStock = new JLabel("Stock");
		lblStock.setBounds(226, 121, 43, 21);
		lblStock.setFont(new Font("Tahoma", Font.PLAIN, 15));
		jf.getContentPane().add(lblStock);
		
		
		
		stock = new JTextField();
		stock.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent arg0) {
				stock.setOpaque(true);
				stock.setBackground(Color.black);
				stock.setForeground(Color.WHITE);
			}
			@Override
			public void focusLost(FocusEvent arg0) {
				stock.setBackground(new Color(240, 230, 140));
				stock.setForeground(Color.black);
			}
		});
		stock.setOpaque(false);
		stock.setBorder(null);
		stock.setBounds(319, 119, 90, 28);
		stock.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode()==KeyEvent.VK_ENTER){
					salerate.requestFocus();
				}else if(e.getKeyCode()==KeyEvent.VK_ESCAPE){
	            	 jf.dispose();
	             }
				
			}
		});
		stock.setHorizontalAlignment(SwingConstants.RIGHT);
		stock.setColumns(10);
		jf.getContentPane().add(stock);
		
		JLabel lblSaleRate = new JLabel("Sale Rate");
		lblSaleRate.setBounds(444, 116, 71, 21);
		lblSaleRate.setFont(new Font("Tahoma", Font.PLAIN, 15));
		jf.getContentPane().add(lblSaleRate);
		
		salerate = new JTextField();
		salerate.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent arg0) {
				salerate.setOpaque(true);
				salerate.setBackground(Color.black);
				salerate.setForeground(Color.white);
			}
			@Override
			public void focusLost(FocusEvent arg0) {
				salerate.setBackground(new Color(240, 230, 140));
		
				salerate.setForeground(Color.black);
			}
		});
		salerate.setOpaque(false);
		salerate.setBorder(null);
		salerate.setBounds(534, 114, 124, 28);
		salerate.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode()==KeyEvent.VK_ENTER){
					purchaserate.requestFocus();
				}else if(e.getKeyCode()==KeyEvent.VK_ESCAPE){
	            	 jf.dispose();
	             }
			}
		});
		salerate.setHorizontalAlignment(SwingConstants.RIGHT);
		jf.getContentPane().add(salerate);
		salerate.setColumns(10);
		
		JLabel lblPurchaseRate = new JLabel("Purchase Rate");
		lblPurchaseRate.setBounds(701, 117, 97, 28);
		lblPurchaseRate.setFont(new Font("Tahoma", Font.PLAIN, 15));
		jf.getContentPane().add(lblPurchaseRate);
		

		final String[] tax ={"0","5","12","18","28"};
		@SuppressWarnings({ "rawtypes", "unchecked" })
		final
		JComboBox comboBox_1 = new JComboBox(tax);
		comboBox_1.setBounds(98, 173, 71, 23);
		comboBox_1.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode()==KeyEvent.VK_ENTER){
					cessrate.requestFocus();
				}else if(e.getKeyCode()==KeyEvent.VK_ESCAPE){
	            	 jf.dispose();
	             }
			}
		});
		jf.getContentPane().add(comboBox_1);
		
		purchaserate = new JTextField();
		purchaserate.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent arg0) {
				purchaserate.setOpaque(true);
				purchaserate.setBackground(Color.black);
				purchaserate.setForeground(Color.white);
			}
			@Override
			public void focusLost(FocusEvent arg0) {
				purchaserate.setBackground(new Color(240, 230, 140));
			
				purchaserate.setForeground(Color.black);
			}
		});
		purchaserate.setOpaque(false);
		purchaserate.setBorder(null);
		purchaserate.setBounds(816, 119, 124, 28);
		purchaserate.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				
				if(e.getKeyCode()==KeyEvent.VK_ENTER){
					comboBox_1.requestFocus();
				}else if(e.getKeyCode()==KeyEvent.VK_ESCAPE){
	            	 jf.dispose();
	             }
			}
		});
		purchaserate.setHorizontalAlignment(SwingConstants.RIGHT);
		jf.getContentPane().add(purchaserate);
		purchaserate.setColumns(10);
		
		JLabel lblTaxRate = new JLabel("Tax ");
		lblTaxRate.setBounds(33, 173, 32, 23);
		lblTaxRate.setFont(new Font("Tahoma", Font.PLAIN, 15));
		jf.getContentPane().add(lblTaxRate);
		

		final JTextArea ta = new JTextArea();
		ta.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent arg0) {
				ta.setOpaque(true);
				ta.setBackground(Color.black);
				ta.setForeground(Color.white);
			}
			@Override
			public void focusLost(FocusEvent arg0) {
				ta.setBackground(new Color(240, 230, 140));
			
				ta.setForeground(Color.black);
			}
		});
		ta.setOpaque(false);
		ta.setBorder(null);
		ta.setBounds(140, 218, 792, 56);
		
		JLabel lblCessRate = new JLabel("Cess Rate");
		lblCessRate.setBounds(226, 168, 90, 28);
		lblCessRate.setFont(new Font("Tahoma", Font.PLAIN, 15));
		jf.getContentPane().add(lblCessRate);
		
		cessrate = new JTextField();
		cessrate.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent arg0) {
				cessrate.setOpaque(true);
				cessrate.setBackground(Color.black);
				cessrate.setForeground(Color.white);
			}
			@Override
			public void focusLost(FocusEvent arg0) {
				cessrate.setBackground(new Color(240, 230, 140));
				
				cessrate.setForeground(Color.black);
			}
		});
		cessrate.setOpaque(false);
		cessrate.setBorder(null);
		cessrate.setBounds(319, 170, 90, 28);
		cessrate.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode()==KeyEvent.VK_ENTER){
				
					mfgtext.requestFocus();
				}else if(e.getKeyCode()==KeyEvent.VK_ESCAPE){
	            	 jf.dispose();
	             }
			}
		});
		cessrate.setHorizontalAlignment(SwingConstants.RIGHT);
		jf.getContentPane().add(cessrate);
		cessrate.setColumns(10);
		
		JLabel lblDescription = new JLabel("Description");
		lblDescription.setBounds(33, 215, 90, 56);
		lblDescription.setFont(new Font("Tahoma", Font.PLAIN, 15));
		jf.getContentPane().add(lblDescription);
		
		

		
		final JButton btnSave = new JButton("Save");
		btnSave.setBounds(568, 359, 90, 33);
		btnSave.setBackground(Color.GREEN);
		btnSave.setFont(new Font("Tahoma", Font.PLAIN, 11));
		jf.getContentPane().add(btnSave);
		
		final JTextArea ta1 = new JTextArea();
		ta1.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent arg0) {
				ta1.setOpaque(true);
				ta1.setBackground(Color.black);
				ta1.setForeground(Color.white);
			}
			@Override
			public void focusLost(FocusEvent arg0) {
				ta1.setBackground(new Color(240, 230, 140));
				
				ta1.setForeground(Color.black);
			}
		});
		ta1.setOpaque(false);
		ta1.setBorder(null);
		ta1.setBounds(140, 285, 792, 56);
		ta1.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode()==KeyEvent.VK_ENTER){
					btnSave.requestFocus();
				}else if(e.getKeyCode()==KeyEvent.VK_ESCAPE){
	            	 jf.dispose();
	             }
			}
		});
		jf.getContentPane().add(ta1);
		
		
		ta.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode()==KeyEvent.VK_ENTER){
					ta1.requestFocus();
				}else if(e.getKeyCode()==KeyEvent.VK_ESCAPE){
	            	 jf.dispose();
	             }
			}
		});
		jf.getContentPane().add(ta);
		
		JLabel lblRemarks = new JLabel("Remarks");
		lblRemarks.setBounds(33, 282, 90, 56);
		lblRemarks.setFont(new Font("Tahoma", Font.PLAIN, 15));
		jf.getContentPane().add(lblRemarks);
		
		
		
		JButton btnClose = new JButton("Clear");
		btnClose.setBounds(796, 359, 90, 33);
		btnClose.setBackground(Color.RED);
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				itemname.setText(" ");
				sac.setText(" ");
				salerate.setText(" ");
				purchaserate.setText(" ");
				cessrate.setText(" ");
				stock.setText(" ");
				ta.setText(" ");
				ta1.setText(" ");
				mfgtext.setText(" ");
				comboBox_1.setSelectedIndex(0);
			}
		});
		
				
		
		
		
		unit.setBounds(98, 120, 71, 26);
		jf.getContentPane().add(unit);
		unit.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode()==KeyEvent.VK_ENTER){
					stock.requestFocus();
				}else if(e.getKeyCode()==KeyEvent.VK_ESCAPE){
	            	 jf.dispose();
	             }
			}
		});
		

		final JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(226, 359, 249, 33);
		lblNewLabel.setForeground(new Color(255, 0, 0));
		lblNewLabel.setToolTipText("");
		lblNewLabel.setFont(new Font("SansSerif", Font.PLAIN, 15));
		jf.getContentPane().add(lblNewLabel);
		jf.getContentPane().add(btnClose);
		
		final JLabel NAMELBL = new JLabel("");
		NAMELBL.setForeground(new Color(240, 230, 140));
		NAMELBL.setBounds(138, 55, 321, 14);
		jf.getContentPane().add(NAMELBL);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 436, 950, 241);
		jf.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				DefaultTableModel mt = (DefaultTableModel)table.getModel();
				String name = mt.getValueAt(table.getSelectedRow(), 0).toString();
				
				if(e.getKeyCode()==KeyEvent.VK_DELETE) {
					
					String sql = "DELETE FROM ADDITEMS WHERE ITEM_NAME = '"+name+"'";
					try {
						Connection con = DriverManager.getConnection("jdbc:h2:C:/SimpleGST/GST","sa","");
						Statement st = con.createStatement();
						st.execute(sql);
					//	System.out.println("deleted");
						String up = "SELECT * FROM ADDITEMS ORDER BY ITEM_NAME ASC";
						PreparedStatement ps = con.prepareStatement(up);
						ResultSet rs = ps.executeQuery();
				//		while(rs.next()) {
							table.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
					//	}
						
						
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		});
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
				DefaultTableModel mt = (DefaultTableModel)table.getModel();
				String itemnam =(String) mt.getValueAt(table.getSelectedRow(), 0);
				String mfg =(String) mt.getValueAt(table.getSelectedRow(), 1);
				String sachsn =(String) mt.getValueAt(table.getSelectedRow(), 2);
				String uni =(String) mt.getValueAt(table.getSelectedRow(), 3);
				String sr =(String) mt.getValueAt(table.getSelectedRow(), 4);
				String pr =(String) mt.getValueAt(table.getSelectedRow(), 5);
				String tax =(String) mt.getValueAt(table.getSelectedRow(), 6);
				String stk =(String) mt.getValueAt(table.getSelectedRow(), 7);
				String desc =(String) mt.getValueAt(table.getSelectedRow(), 8);
				String rmrk =(String) mt.getValueAt(table.getSelectedRow(), 9);
				itemname.setText(itemnam);
				NAMELBL.setText(itemnam);
				mfgtext.setText(mfg);
				sac.setText(sachsn);
				unit.setText(uni);
				salerate.setText(sr);
				purchaserate.setText(pr);
				comboBox_1.setSelectedItem(tax);
				stock.setText(stk);
				ta.setText(desc);
				ta1.setText(rmrk);
				
			}
		});
		scrollPane.setViewportView(table);
		
		
	    btnSave.addActionListener(new ActionListener() {
	    	
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				String empt = itemname.getText();
				if(empt.isEmpty()){
					lblNewLabel.setText("FILL ALL * FIELDS");
				}else{
				try {
					
					String item=itemname.getText();
					String hsn = sac.getText();
					String ut =  unit.getText();
					String sale = salerate.getText();
					String purchase = purchaserate.getText();
					String stck = stock.getText();
					String desc = ta.getText();
					String rmrk = ta1.getText();
					String tx =  comboBox_1.getSelectedItem().toString();
					String mfg = mfgtext.getText();
					
					
					Connection con=DriverManager.getConnection("jdbc:h2:C:/SimpleGST/GST","sa","");
					
					PreparedStatement ps = con.prepareStatement("insert into additems values(?,?,?,?,?,?,?,?,?,?)");
				   
				    ps.setString(1, item);
				    ps.setString(2, mfg);
				    ps.setString(3, hsn);
				    ps.setString(4, ut);
				    ps.setString(5, sale);
				    ps.setString(6, purchase);
				    ps.setString(7, tx);
				    ps.setString(8, stck);
				    ps.setString(9, desc);
				    ps.setString(10, rmrk);
				    
				  ps.executeUpdate();
			//		System.out.println("item added successfully"); 
					
					
					   ResultSet rs = null;

						
						String h = "SELECT * FROM ADDITEMS ORDER BY ITEM_NAME ASC";
						PreparedStatement st = null;
						
							st = con.prepareStatement(h);
						
							rs = st.executeQuery();
						
				//			while(rs.next()){
							table.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
		          //                }
					
						itemname.requestFocus();		
						
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					
				}
				
				itemname.setText(" ");
				sac.setText(" ");
				unit.setText(" ");
				salerate.setText(" ");
				purchaserate.setText(" ");
				cessrate.setText(" ");
				stock.setText(" ");
				ta.setText(" ");
				ta1.setText(" ");
				mfgtext.setText(" ");
				
				
			}
				 
			  
			}
			
		});
       

	    btnSave.addKeyListener(new KeyAdapter() {
	
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				String empt = itemname.getText();
				if(empt.isEmpty()){
					lblNewLabel.setText("FILL ALL * FIELDS");
				}else if (e.getKeyCode()==KeyEvent.VK_ENTER){
				try {
					
					String item=itemname.getText();
					String hsn = sac.getText();
					String ut =  unit.getText();
					String sale = salerate.getText();
					String purchase = purchaserate.getText();
					String stck = stock.getText();
					String desc = ta.getText();
					String rmrk = ta1.getText();
					String tx =  comboBox_1.getSelectedItem().toString();
					String mg = mfgtext.getText();
					
					
					Connection con=DriverManager.getConnection("jdbc:h2:C:/SimpleGST/GST","sa","");
					
					PreparedStatement ps = con.prepareStatement("insert into additems values(?,?,?,?,?,?,?,?,?,?)");
				 
				    ps.setString(1, item);
				    ps.setString(2, mg);
				    ps.setString(3, hsn);
				    ps.setString(4, ut);
				    ps.setString(5, sale);
				    ps.setString(6, purchase);
				    ps.setString(7, tx);
				    ps.setString(8, stck);
				    ps.setString(9, desc);
				    ps.setString(10, rmrk);
				    
				  ps.executeUpdate();
					System.out.println("item added successfully"); 
				} catch (SQLException v) {
					// TODO Auto-generated catch block
					v.printStackTrace();
					
				}
				
				itemname.setText(" ");
				sac.setText(" ");
				unit.setText(" ");
				salerate.setText(" ");
				purchaserate.setText(" ");
				cessrate.setText(" ");
				stock.setText(" ");
				ta.setText(" ");
				ta1.setText(" ");
				mfgtext.setText(" ");
			
				 
			    Connection vie = null;
				try {
					vie = DriverManager.getConnection("jdbc:h2:C:/SimpleGST/GST","sa","");
					   ResultSet rs = null;

						
						String h = "SELECT * FROM ADDITEMS ORDER BY ITEM_NAME ASC";
						PreparedStatement st = null;
						st = vie.prepareStatement(h);
						rs = st.executeQuery();
			//			while(rs.next()){
							table.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
		      //              }
					
				} catch (SQLException ve) {
					// TODO Auto-generated catch block
					ve.printStackTrace();
				}
				
			   
			 
				
				itemname.requestFocus();		
				
			}

			}

		});
	    
		jf.setVisible(true);
		jf.setResizable(false);
		jf.setBounds(204,31,950,720);
		jf.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		jf.getContentPane().setLayout(null);
		
		JLabel label = new JLabel("*");
		label.setForeground(Color.RED);
		label.setBounds(111, 75, 13, 14);
		jf.getContentPane().add(label);
		
		JLabel label_1 = new JLabel("*");
		label_1.setForeground(Color.RED);
		label_1.setBounds(61, 121, 13, 14);
		jf.getContentPane().add(label_1);
		
		JLabel label_2 = new JLabel("*");
		label_2.setForeground(Color.RED);
		label_2.setBounds(262, 119, 13, 21);
		jf.getContentPane().add(label_2);
		
		JLabel label_3 = new JLabel("*");
		label_3.setForeground(Color.RED);
		label_3.setBounds(511, 121, 13, 14);
		jf.getContentPane().add(label_3);
		
		JLabel label_4 = new JLabel("*");
		label_4.setForeground(Color.RED);
		label_4.setBounds(763, 75, 13, 14);
		jf.getContentPane().add(label_4);
		
		JLabel label_5 = new JLabel("*");
		label_5.setForeground(Color.RED);
		label_5.setBounds(797, 126, 13, 14);
		jf.getContentPane().add(label_5);
		
		JLabel label_6 = new JLabel("*");
		label_6.setForeground(Color.RED);
		label_6.setBounds(296, 175, 13, 14);
		jf.getContentPane().add(label_6);
		
		JLabel label_7 = new JLabel("*");
		label_7.setForeground(Color.RED);
		label_7.setBounds(61, 175, 13, 14);
		jf.getContentPane().add(label_7);
		
		JLabel lblDelete = new JLabel("Enter Item Name  :");
		lblDelete.setBounds(19, 403, 106, 22);
		jf.getContentPane().add(lblDelete);
		
		deletebox = new JTextField();
		deletebox.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent arg0) {
				deletebox.setOpaque(true);
				deletebox.setBackground(Color.BLACK);
				deletebox.setForeground(Color.white);
			}
			@Override
			public void focusLost(FocusEvent arg0) {
				deletebox.setBackground(new Color(240, 230, 140));
				
				deletebox.setForeground(Color.black);
			}
		});
		deletebox.setOpaque(false);
		deletebox.setBorder(null);
		deletebox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String delete = deletebox.getText();
				String sql = "DELETE FROM ADDITEMS WHERE ITEM_NAME = '"+delete+"'";
				try {
					Connection con = DriverManager.getConnection("jdbc:h2:C:/SimpleGST/GST","sa","");
					Statement st = con.createStatement();
					st.execute(sql);
			//		System.out.println("deleted");
					String up = "SELECT * FROM ADDITEMS ORDER BY ITEM_NAME ASC";
					PreparedStatement ps = con.prepareStatement(up);
					ResultSet rs = ps.executeQuery();
		//			while(rs.next()) {
						table.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
			//		}
					
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		deletebox.setBounds(121, 403, 141, 20);
		jf.getContentPane().add(deletebox);
		deletebox.setColumns(10);
		
		JButton btnDelete = new JButton("delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String delete = deletebox.getText();
				String sql = "DELETE FROM ADDITEMS WHERE ITEM_NAME = '"+delete+"'";
				try {
					Connection con = DriverManager.getConnection("jdbc:h2:C:/SimpleGST/GST","sa","");
					Statement st = con.createStatement();
					st.execute(sql);
			//		System.out.println("deleted");
					String up = "SELECT * FROM ADDITEMS ORDER BY ITEM_NAME ASC";
					PreparedStatement ps = con.prepareStatement(up);
					ResultSet rs = ps.executeQuery();
			//		while(rs.next()) {
						table.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
				//	}
					
					
					
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		btnDelete.setBounds(280, 402, 89, 23);
		jf.getContentPane().add(btnDelete);
		
		JLabel lblMfg = new JLabel("Mfg ");
		lblMfg.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblMfg.setBounds(444, 171, 32, 21);
		jf.getContentPane().add(lblMfg);
		
		mfgtext = new JTextField();
		mfgtext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ta.requestFocus();
			}
		});
		mfgtext.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent arg0) {
				mfgtext.setOpaque(true);
				mfgtext.setBackground(Color.black);
				mfgtext.setForeground(Color.white);
			}
			@Override
			public void focusLost(FocusEvent arg0) {
				mfgtext.setBackground(new Color(240, 230, 140));
			
				mfgtext.setForeground(Color.black);
			}
		});
		mfgtext.setOpaque(false);
		mfgtext.setBorder(null);
		mfgtext.setColumns(10);
		mfgtext.setBounds(521, 170, 137, 28);
		jf.getContentPane().add(mfgtext);
		
		JLabel label_8 = new JLabel("*");
		label_8.setForeground(Color.RED);
		label_8.setBounds(474, 171, 13, 14);
		jf.getContentPane().add(label_8);
		
		JLabel label_9 = new JLabel(":");
		label_9.setBounds(124, 75, 13, 14);
		jf.getContentPane().add(label_9);
		
		JLabel label_10 = new JLabel(":");
		label_10.setBounds(75, 126, 13, 14);
		jf.getContentPane().add(label_10);
		
		JLabel label_11 = new JLabel(":");
		label_11.setBounds(75, 177, 13, 14);
		jf.getContentPane().add(label_11);
		
		JLabel label_12 = new JLabel(":");
		label_12.setBounds(272, 126, 13, 14);
		jf.getContentPane().add(label_12);
		
		JLabel label_14 = new JLabel(":");
		label_14.setBounds(525, 107, 13, 36);
		jf.getContentPane().add(label_14);
		
		JLabel label_15 = new JLabel(":");
		label_15.setBounds(484, 177, 13, 14);
		jf.getContentPane().add(label_15);
		
		JLabel label_13 = new JLabel(":");
		label_13.setBounds(306, 177, 13, 14);
		jf.getContentPane().add(label_13);
		
		JLabel label_16 = new JLabel(":");
		label_16.setBounds(773, 82, 13, 14);
		jf.getContentPane().add(label_16);
		
		JLabel label_17 = new JLabel(":");
		label_17.setBounds(807, 128, 13, 14);
		jf.getContentPane().add(label_17);
		
		JLabel label_18 = new JLabel(":");
		label_18.setBounds(111, 238, 13, 14);
		jf.getContentPane().add(label_18);
		
		JLabel label_19 = new JLabel(":");
		label_19.setBounds(98, 305, 13, 14);
		jf.getContentPane().add(label_19);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.setBackground(Color.CYAN);
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String item=itemname.getText();
				String item1=NAMELBL.getText();
				String hsn = sac.getText();
				String ut =  unit.getText();
				String sale = salerate.getText();
				String purchase = purchaserate.getText();
				String stck = stock.getText();
				String desc = ta.getText();
				String rmrk = ta1.getText();
				String tx =  comboBox_1.getSelectedItem().toString();
				String mg = mfgtext.getText();
				
				try {
					Connection con=DriverManager.getConnection("jdbc:h2:C:/SimpleGST/GST","sa","");
					String sql ="update additems set item_name = '"+item+"' , UNIT = '"+ut+"' ,  manufacturer = '"+mg+"', sac_hsn = '"+hsn+"',sale_rate = '"+sale+"', purchase_rate = '"+purchase+"', tax = '"+tx+"',stock = '"+stck+"',description = '"+desc+"', remarks = '"+rmrk+"' where item_name = '"+item1+"'" ;
					Statement st = con.createStatement();
					st.execute(sql);
					String up = "SELECT * FROM ADDITEMS ORDER BY ITEM_NAME ASC";
					PreparedStatement ps = con.prepareStatement(up);
					ResultSet rs = ps.executeQuery();
				//	while(rs.next()) {
						table.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
			//		}
					
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				itemname.setText(" ");
				sac.setText(" ");
				salerate.setText(" ");
				purchaserate.setText(" ");
				cessrate.setText(" ");
				stock.setText(" ");
				ta.setText(" ");
				ta1.setText(" ");
				mfgtext.setText(" ");
				comboBox_1.setSelectedIndex(0);
			}
		});
		
		btnUpdate.setBounds(680, 359, 89, 33);
		jf.getContentPane().add(btnUpdate);
		
		
		
		itemlist();
		
		
		
	
}
}
