package gst;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;

import javax.swing.*;
import javax.swing.plaf.basic.BasicInternalFrameUI;
import javax.swing.text.BadLocationException;
import java.awt.Font;
import java.awt.Color;

import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.border.BevelBorder;

public class Main  {
	private static JTextField txtAuthorisedUser;
	private static JTextArea textArea;
	static Connection con =null;
	static Statement st =null;
	static ResultSet rs = null;
	public static JInternalFrame auth = new JInternalFrame();
	static JInternalFrame sale;
	public static JInternalFrame txninternalframe;
	
	
	
	
	
	
	public static void main(String[] args) { 
		
		Toolkit.getDefaultToolkit().setLockingKeyState(KeyEvent.VK_CAPS_LOCK, true);
		
	
		 try {
	            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
	                if ("Windows".equals(info.getName())) {
	                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
	                    break;
	                }
	            }
	        } catch (ClassNotFoundException ex) {
	            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        } catch (InstantiationException ex) {
	            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        } catch (IllegalAccessException ex) {
	            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
	            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        }
		
		 
		 final CreatingTableAndPreData o = new CreatingTableAndPreData();
		 final Item a = new Item();
		 final Stockm b = new Stockm();
	 final JFrame g =  new JFrame();
	
	
	 g.getContentPane().setBackground(Color.GRAY);
	 String username =System.getProperty("user.name"); 
	 g.setTitle("Simple GST - C:/SimpleGST/GST "+"Username -"+username);
	 g.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	 g.setSize(1383,760);
	 g.getContentPane().setLayout(null);
	 
	


//  ------ masters internal frame--------
	
	final JInternalFrame master = new JInternalFrame();
	master.getContentPane().setBackground(new Color(51, 51, 153));
	BasicInternalFrameUI mas = (BasicInternalFrameUI)master.getUI();
	mas.setNorthPane(null);
	
	JPanel panel = new JPanel();
	panel.setFont(new Font("SansSerif", Font.PLAIN, 17));
	panel.setBackground(Color.DARK_GRAY);
	panel.setBounds(0, 0, 196, 734);
	g.getContentPane().add(panel);
	panel.setLayout(null);
	//end

	
	JButton btnExit = new JButton("Exit");
	btnExit.setBounds(0, 56, 127, 45);
	btnExit.setOpaque(false);
	btnExit.setMnemonic(KeyEvent.VK_Q);
	btnExit.setMargin(new Insets(2, 14, 2, 65));
	btnExit.setForeground(Color.WHITE);
	btnExit.setFont(new Font("SansSerif", Font.PLAIN, 15));
	btnExit.setContentAreaFilled(false);
	btnExit.setBackground(Color.GRAY);
	btnExit.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			g.dispose();
		}
	});
	
	//-------------- FILE INTERNAL FRAME --------------
	
		
	final JInternalFrame file = new JInternalFrame();
	file.getContentPane().setBackground(new Color(51, 51, 153));
	file.getContentPane().setLayout(null);
	file.getContentPane().add(btnExit);
	file.setBorder(null);
	file.setBounds(196, 153, 127, 105);
	g.getContentPane().add(file);
	BasicInternalFrameUI bi = (BasicInternalFrameUI)file.getUI();
	bi.setNorthPane(null);

	panel.addMouseListener(new MouseAdapter() {
		@Override
		public void mouseClicked(MouseEvent arg0) {
			file.dispose();
			master.dispose();
			Item.jf.setVisible(true);
			
		}
	});
	
	 g.getContentPane().addMouseListener(new MouseAdapter() {
		 	@Override
		 	public void mouseClicked(MouseEvent arg0) {
		 		file.dispose();
		 	}
		 });
	
	
	 
	JButton btnNewButton_1 = new JButton("New");
	btnNewButton_1.setBounds(0, 0, 127, 55);
	btnNewButton_1.setMargin(new Insets(2, 14, 2, 65));
	btnNewButton_1.setFont(new Font("SansSerif", Font.PLAIN, 15));
	btnNewButton_1.setMnemonic(KeyEvent.VK_N);
	btnNewButton_1.setForeground(Color.WHITE);
	btnNewButton_1.setContentAreaFilled(false);
	btnNewButton_1.setOpaque(false);
	btnNewButton_1.setBackground(Color.GRAY);
	btnNewButton_1.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			
			
			o.createDetails();
			JOptionPane.showMessageDialog(g, "File Created","File", JOptionPane.PLAIN_MESSAGE);
		}
	});
	file.getContentPane().add(btnNewButton_1);
	
	JButton btnfile = new JButton("File");
	btnfile.setContentAreaFilled(false);
	btnfile.setMargin(new Insets(2, 0, 2, 120));
	btnfile.setForeground(Color.WHITE);
	btnfile.setBackground(Color.LIGHT_GRAY);
	btnfile.setMnemonic(KeyEvent.VK_F);
	btnfile.setFont(new Font("SansSerif", Font.BOLD, 17));
	btnfile.setBounds(0, 185, 196, 62);
	panel.add(btnfile);
	

	btnfile.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
			
			file.setVisible(true);
			master.dispose();
			Item.jf.dispose();
			sale.dispose();
				
		}
		
	});

	
	
	JButton btnMasters = new JButton("Masters");
	btnMasters.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
       file.dispose();
       master.setVisible(true);
       Item.jf.dispose();
       sale.dispose();
      
		}
	});
	btnMasters.setContentAreaFilled(false);
	btnMasters.setMnemonic(KeyEvent.VK_F);
	btnMasters.setMargin(new Insets(2, 0, 2, 90));
	btnMasters.setForeground(Color.WHITE);
	btnMasters.setFont(new Font("SansSerif", Font.BOLD, 17));
	btnMasters.setBackground(Color.LIGHT_GRAY);
	btnMasters.setBounds(0, 250, 196, 62);
	panel.add(btnMasters);
	
	JButton btnSale = new JButton("Sale");
	btnSale.addActionListener(new ActionListener() {
		
		
		public void actionPerformed(ActionEvent arg0) {
			sale.setVisible(true);
			if(master.isVisible() || file.isVisible()) {
				master.dispose();
				file.dispose();
			}
		}
	});
	btnSale.setContentAreaFilled(false);
	btnSale.setMnemonic(KeyEvent.VK_F);
	btnSale.setMargin(new Insets(2, 0, 2, 120));
	btnSale.setForeground(Color.WHITE);
	btnSale.setFont(new Font("SansSerif", Font.BOLD, 17));
	btnSale.setBackground(Color.LIGHT_GRAY);
	btnSale.setBounds(0, 315, 196, 62);
	panel.add(btnSale);
	
	JButton button_2 = new JButton("File");
	button_2.setContentAreaFilled(false);
	button_2.setMargin(new Insets(2, 0, 2, 120));
	button_2.setForeground(Color.WHITE);
	button_2.setFont(new Font("SansSerif", Font.BOLD, 17));
	button_2.setBackground(Color.LIGHT_GRAY);
	button_2.setBounds(0, 380, 196, 62);
	panel.add(button_2);
	
	JButton button_3 = new JButton("File");
	button_3.setContentAreaFilled(false);
	button_3.setMnemonic(KeyEvent.VK_F);
	button_3.setMargin(new Insets(2, 0, 2, 120));
	button_3.setForeground(Color.WHITE);
	button_3.setFont(new Font("SansSerif", Font.BOLD, 17));
	button_3.setBackground(Color.LIGHT_GRAY);
	button_3.setBounds(0, 445, 196, 62);
	panel.add(button_3);
	
	JButton btnTransaction = new JButton("Transaction");
	btnTransaction.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
			
			txninternalframe.setVisible(true);
		}
	});
	btnTransaction.setContentAreaFilled(false);
	btnTransaction.setMnemonic(KeyEvent.VK_F);
	btnTransaction.setMargin(new Insets(2, 0, 2, 60));
	btnTransaction.setForeground(Color.WHITE);
	btnTransaction.setFont(new Font("SansSerif", Font.BOLD, 17));
	btnTransaction.setBackground(Color.LIGHT_GRAY);
	btnTransaction.setBounds(0, 510, 196, 62);
	panel.add(btnTransaction);
	
	final JInternalFrame settings = new JInternalFrame("");
	settings.setBorder(null);
	settings.setBounds(196, 508, 209, 213);
	settings.setBackground(new Color(51,51,153));
	g.getContentPane().add(settings);
	settings.getContentPane().setLayout(null);
	
	JButton btnSetting = new JButton("Settings");
	btnSetting.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
			settings.setVisible(true);
		}
	});
	btnSetting.setContentAreaFilled(false);
	btnSetting.setMnemonic(KeyEvent.VK_F);
	btnSetting.setMargin(new Insets(2, 0, 2, 90));
	btnSetting.setForeground(Color.WHITE);
	btnSetting.setFont(new Font("SansSerif", Font.BOLD, 17));
	btnSetting.setBackground(Color.LIGHT_GRAY);
	btnSetting.setBounds(0, 575, 196, 62);
	panel.add(btnSetting);
	
	JButton button_6 = new JButton("File");
	button_6.setContentAreaFilled(false);
	button_6.setMnemonic(KeyEvent.VK_F);
	button_6.setMargin(new Insets(2, 0, 2, 120));
	button_6.setForeground(Color.WHITE);
	button_6.setFont(new Font("SansSerif", Font.BOLD, 17));
	button_6.setBackground(Color.BLUE);
	button_6.setBounds(0, 640, 196, 62);
	panel.add(button_6);
	
	JSeparator separator = new JSeparator();
	separator.setBounds(0, 248, 196, 1);
	panel.add(separator);
	
	JSeparator separator_1 = new JSeparator();
	separator_1.setBounds(0, 313, 196, 1);
	panel.add(separator_1);
	
	JSeparator separator_2 = new JSeparator();
	separator_2.setBounds(0, 378, 196, 1);
	panel.add(separator_2);
	
	JSeparator separator_3 = new JSeparator();
	separator_3.setBounds(0, 443, 196, 1);
	panel.add(separator_3);
	
	JSeparator separator_4 = new JSeparator();
	separator_4.setBounds(0, 508, 196, 1);
	panel.add(separator_4);
	
	JSeparator separator_5 = new JSeparator();
	separator_5.setBounds(0, 573, 196, 1);
	panel.add(separator_5);
	
	JSeparator separator_6 = new JSeparator();
	separator_6.setBounds(0, 638, 196, 1);
	panel.add(separator_6);
	
	JSeparator separator_7 = new JSeparator();
	separator_7.setBounds(0, 185, 196, 1);
	panel.add(separator_7);
	
	txtAuthorisedUser = new JTextField();
	txtAuthorisedUser.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
		
			file.dispose();
			Item.jf.setVisible(true);
		}
	});
	txtAuthorisedUser.setEditable(false);
	txtAuthorisedUser.setBorder(null);
	txtAuthorisedUser.setBackground(Color.DARK_GRAY);
	txtAuthorisedUser.setFont(new Font("SansSerif", Font.PLAIN, 15));
	txtAuthorisedUser.setForeground(Color.RED);
	txtAuthorisedUser.setText("Authorised User :-");
	txtAuthorisedUser.setBounds(10, 11, 176, 20);
	panel.add(txtAuthorisedUser);
	txtAuthorisedUser.setColumns(10);
	
	textArea = new JTextArea();
	textArea.setFont(new Font("SansSerif", Font.PLAIN, 17));
	textArea.addFocusListener(new FocusAdapter() {
		@Override
		public void focusGained(FocusEvent arg0) {
			file.dispose();
			Item.jf.setVisible(true);
		}
	});
	textArea.setEditable(false);
	textArea.setForeground(Color.RED);
	textArea.setBorder(null);
	textArea.setBackground(Color.DARK_GRAY);
	textArea.setBounds(10, 42, 176, 144);
	panel.add(textArea);
	
	JButton btnItemMaster = new JButton("Item Master");
	btnItemMaster.setBounds(10, 48, 197, 43);
	btnItemMaster.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
			master.dispose();
		  try {
			Item.main(null);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			
		}
	});
	
	JButton btnCompanyDetails = new JButton("Company Details");
	btnCompanyDetails.setBounds(0, 0, 207, 43);
	btnCompanyDetails.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
			master.dispose();
			try {
				AddCompany.main(null);
			} catch (BadLocationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	});
	master.getContentPane().setLayout(null);
	btnCompanyDetails.setMargin(new Insets(2, 0, 2, 52));
	btnCompanyDetails.setForeground(Color.WHITE);
	btnCompanyDetails.setFont(new Font("SansSerif", Font.PLAIN, 15));
	btnCompanyDetails.setContentAreaFilled(false);
	master.getContentPane().add(btnCompanyDetails);
	btnItemMaster.setMargin(new Insets(2, 0, 2, 95));
	btnItemMaster.setForeground(Color.WHITE);
	btnItemMaster.setFont(new Font("SansSerif", Font.PLAIN, 15));
	btnItemMaster.setContentAreaFilled(false);
	master.getContentPane().add(btnItemMaster);
	
	JButton btnCompanyAccountDetails = new JButton("Stock Master");
	btnCompanyAccountDetails.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
			Stockm.main(null);
			b.stock();
		}
	});
	btnCompanyAccountDetails.setBounds(0, 156, 207, 43);
	btnCompanyAccountDetails.setMargin(new Insets(2, 0, 2, 80));
	btnCompanyAccountDetails.setForeground(Color.WHITE);
	btnCompanyAccountDetails.setFont(new Font("SansSerif", Font.PLAIN, 15));
	btnCompanyAccountDetails.setContentAreaFilled(false);
	master.getContentPane().add(btnCompanyAccountDetails);
	
	JButton btnUnitMaster = new JButton("Add Customer");
	btnUnitMaster.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
			AddCustomer.main(null);
			sale.dispose();
		}
	});
	btnUnitMaster.setBounds(10, 102, 197, 43);
	master.getContentPane().add(btnUnitMaster);
	btnUnitMaster.setMargin(new Insets(2, 0, 2, 80));
	btnUnitMaster.setForeground(Color.WHITE);
	btnUnitMaster.setFont(new Font("SansSerif", Font.PLAIN, 15));
	btnUnitMaster.setContentAreaFilled(false);
	master.setBorder(null);
	master.setBounds(196, 153, 209, 245);
	g.getContentPane().add(master);
	
	textArea.setText(username);
	
	sale = new JInternalFrame("New JInternalFrame");
	sale.setBounds(195, 256, 209, 154);
	g.getContentPane().add(sale);
	sale.setBorder(null);
	sale.getContentPane().setBackground(new Color(51,51,153));
	sale.getContentPane().setLayout(null);
	BasicInternalFrameUI sell = (BasicInternalFrameUI)sale.getUI();
	sell.setNorthPane(null);
	
	JButton btnNewSale = new JButton("New Sale");
	btnNewSale.setBorderPainted(false);
	btnNewSale.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
			Invoice.main(null);			
		}
	});
	
	btnNewSale.setMargin(new Insets(2, 0, 2, 80));
	btnNewSale.setFont(new Font("Tahoma", Font.PLAIN, 15));
	btnNewSale.setForeground(new Color(255, 255, 255));
	btnNewSale.setOpaque(false);
	btnNewSale.setBounds(0, 0, 209, 45);
	sale.getContentPane().add(btnNewSale);
	
	
	
	JButton btnInvoiceSettings = new JButton("Invoice Settings");
	btnInvoiceSettings.setFont(new Font("SansSerif", Font.PLAIN, 15));
	btnInvoiceSettings.setBorderPainted(false);
	btnInvoiceSettings.setMargin(new Insets(2, 14, 2, 80));
	btnInvoiceSettings.setForeground(Color.WHITE);
	btnInvoiceSettings.setBounds(0, 0, 209, 38);
	btnInvoiceSettings.setBackground(new Color(51,51,153));
	settings.getContentPane().add(btnInvoiceSettings);
	
	JButton btnChangePassword = new JButton("Change Password");
	btnChangePassword.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
		  ChangeAdmin.main(null);
		}
	});
	btnChangePassword.setMargin(new Insets(2, 14, 2, 60));
	btnChangePassword.setForeground(Color.WHITE);
	btnChangePassword.setFont(new Font("SansSerif", Font.PLAIN, 15));
	btnChangePassword.setBorderPainted(false);
	btnChangePassword.setBackground(new Color(51, 51, 153));
	btnChangePassword.setBounds(0, 41, 209, 38);
	settings.getContentPane().add(btnChangePassword);
	
    txninternalframe = new JInternalFrame("");
	txninternalframe.getContentPane().setLayout(null);
	
	JButton btnPastTransaction = new JButton("Past Transaction");
	btnPastTransaction.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
			PastTransaction.main(null);
		}
	});
	btnPastTransaction.setMargin(new Insets(2, 14, 2, 75));
	btnPastTransaction.setForeground(Color.WHITE);
	btnPastTransaction.setFont(new Font("SansSerif", Font.PLAIN, 15));
	btnPastTransaction.setBorderPainted(false);
	btnPastTransaction.setBackground(new Color(51, 51, 153));
	btnPastTransaction.setBounds(0, 0, 209, 38);
	txninternalframe.getContentPane().add(btnPastTransaction);
	
	JButton btnDuesBills = new JButton("Dues Bills");
	btnDuesBills.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
			Dues.main(null);
		}
	});
	btnDuesBills.setMargin(new Insets(2, 14, 2, 115));
	btnDuesBills.setForeground(Color.WHITE);
	btnDuesBills.setFont(new Font("SansSerif", Font.PLAIN, 15));
	btnDuesBills.setBorderPainted(false);
	btnDuesBills.setBackground(new Color(51, 51, 153));
	btnDuesBills.setBounds(0, 41, 209, 38);
	txninternalframe.getContentPane().add(btnDuesBills);
	txninternalframe.setBorder(null);
	txninternalframe.setBackground(new Color(51, 51, 153));
	txninternalframe.setBounds(196, 478, 209, 121);
	g.getContentPane().add(txninternalframe);
	
	BasicInternalFrameUI inte = (BasicInternalFrameUI)settings.getUI();
	inte.setNorthPane(null);
	
	

	
	
  
	
	g.setVisible(true);
	




	
	
	
	
	
	
	}
}
