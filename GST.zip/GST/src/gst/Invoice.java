package gst;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.Caret;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRTableModelDataSource;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Toolkit;
import java.beans.Statement;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JSeparator;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.print.PrinterException;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.JCheckBox;
import java.awt.Component;
import javax.swing.Box;
import javax.swing.JRadioButton;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import javax.swing.JLayeredPane;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;

public class Invoice extends JFrame {

	private JPanel contentPane;
	public static JTextField billnotext;
	public static JTextField datebox;
	private JTextField sachsntext;
	private JTextField qtytext;
	private JTextField pricetext;
	private JTextField taxtext;
	public static JTable table;
	private JTextField discounttext;
	private JTextField utgstrate;
	private JTextField taxablevalue;
	private JTextField taxratetext;
	private JTextField cgstrate;
	private JTextField cgstamount;
	private JTextField utgstamount;
	public static JComboBox namecombo;
	public static JComboBox itemcombo;
	private JLabel custadd1;
	private JLabel custmob;
	private JLabel custadd2;
	private DefaultTableModel model_table = new DefaultTableModel();
	private static JLabel p1;
	public static JLabel grandtotallabel;
	private JLabel totalamountlabel;
	
	private JButton btnAdd;
	public static JLabel namelbl;
	public static JTextField paidtxt;
	public static JTextField duetxt;
	private static JLabel custGstin;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Invoice frame = new Invoice();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	Connection con = null;
	ResultSet rs;
	java.sql.Statement st = null;
	private JTextField discounted;
	private JTextField total;
	private JTextField stocktext;
	private JLabel lblMfg;
	private JTextField mfgtext;
	private JLabel lblDiscountAmt;
	private JLabel label_1;
	private JLabel lblFree;
	private JTextField freetext;
	private JTextField timebox;
	
	
	public void commonMethodForSt(String query) {
		try {
			 st = con.createStatement();
			rs = st.executeQuery(query);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
		}	
	}
	
	
	public void populatename() {
	try {
		con = DriverManager.getConnection("jdbc:h2:C:/SimpleGST/GST","sa","");
		namecombo.addItem("_");
		commonMethodForSt("SELECT * FROM CUSTOMERS ORDER BY NAME ASC ");
		while(rs.next()) {
		namecombo.addItem(rs.getString("name"));
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	}
	
	
	
	public void populateNameDetail() {
		try {
			con = DriverManager.getConnection("jdbc:h2:C:/SimpleGST/GST","sa","");
			String name = namecombo.getSelectedItem().toString();
			commonMethodForSt("SELECT * FROM CUSTOMERS WHERE NAME = '"+name+"'");
			if(rs.next()) {
				custadd1.setText(rs.getString("add1"));
				custadd2.setText(rs.getString("add2"));
				custmob.setText(rs.getString("mob_no"));
				custGstin.setText(rs.getString("gst"));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	
	public void populateItemCombo() {
		try {
			con = DriverManager.getConnection("jdbc:h2:C:/SimpleGST/GST","sa","");
			itemcombo.addItem("_");
			commonMethodForSt("SELECT * FROM ADDITEMS ORDER BY ITEM_NAME ASC");
			while(rs.next()) {
				itemcombo.addItem(rs.getString("item_name"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public void populateItemNameAndDetails() {
		try {
			Class.forName("org.h2.Driver");
			con = DriverManager.getConnection("jdbc:h2:C:/SimpleGST/GST","sa","");
			qtytext.setText("1");
			discounttext.setText("0");
			freetext.setText("0");
			String pname = itemcombo.getSelectedItem().toString();
			commonMethodForSt("select * from additems where item_name='"+pname+"'");
			if(rs.next()) {
				p1.setText(rs.getString("sale_rate"));
				sachsntext.setText(rs.getString("sac_hsn"));
			    pricetext.setText(rs.getString("sale_rate"));
				taxtext.setText(rs.getString("tax"));
				stocktext.setText(rs.getString("stock"));
				mfgtext.setText(rs.getString("manufacturer"));
				

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	
	public void FillingRateField() {
	final String tax = taxtext.getText();
		if(tax.isEmpty()) {
			cgstrate.setText("0");
			utgstrate.setText("0");
			taxratetext.setText("0");
			
			
		}
		if(tax.equals("5")) {
			cgstrate.setText("2.5");
			utgstrate.setText("2.5");
			taxratetext.setText("2.5");
		}
		
		if(tax.equals("12")) {
			cgstrate.setText("6");
			utgstrate.setText("6");
			taxratetext.setText("6");
		}
		if(tax.equals("18")) {
			cgstrate.setText("9");
			utgstrate.setText("9");
			taxratetext.setText("9");
		}
		if(tax.equals("28")) {
			cgstrate.setText("14");
			utgstrate.setText("14");
			taxratetext.setText("14");
		}
	}
	
	
	
	public void fillingAmountField() {
		String check = p1.getText();
		if(check.isEmpty()) {
			p1.setText("0");
		}
	final	String amount = p1.getText();
		float divide =  Float.parseFloat(amount);
		float tot = divide/2;
		String fin = Float.toString(tot);
		cgstamount.setText(fin);
		utgstamount.setText(fin);
		
	}
	
	
	
	public void calculatingTaxValue() {
		String check = p1.getText();
		if(check.isEmpty()) {
			p1.setText("0");
		}
		
    	final	String z = p1.getText();
	    float x = Float.parseFloat(z);
		String ta  = taxtext.getText();
		float t = Float.parseFloat(ta);
	    String a=	qtytext.getText();
	    float b = Float.parseFloat(a);
	    float c = b*x*t/100;
        String f = Float.toString(c);
        taxablevalue.setText(f);
        
        
       
	}
	
	public void Discount() {
		String check = p1.getText();
		if(check.isEmpty()) {
			p1.setText("0");
		}
		
		    
		    final  String a = pricetext.getText();
		    float b = Float.parseFloat(a);
		    String c = discounttext.getText();
	        float d = Float.parseFloat(c);
	        float e = b*d/100;
	        float mm = b-e;
	        String f = Float.toString(mm);
	        discounted.setText(f);
	        String g = taxtext.getText();
	        float h = Float.parseFloat(g);
	        float i = mm+(mm*h/100);
	        String j = Float.toString(i);
	        total.setText(j);
	        
	        
	}
	
	public void updatingPriceAndTaxesAsQty() {
		String check = p1.getText();
		if(check.isEmpty()) {
			p1.setText("0");
		}
	  final String a = p1.getText();
		    float b = Float.parseFloat(a);
		    String c=	qtytext.getText();
	        float d = Float.parseFloat(c);
	        float e = b*d;
	        String f = Float.toString(e);
	        pricetext.setText(f);
	       float g = e/2;
	       String h =  Float.toString(g);
	      
	        cgstamount.setText(h);
	        utgstamount.setText(h);
	     
		
	}
	
	
	
	public void updatingTotalAsPriceAndTax() {
		String check = p1.getText();
		if(check.isEmpty()) {
			p1.setText("0");
		}
		final String a = pricetext.getText();
		    float b =  Float.parseFloat(a);
		 String i = taxablevalue.getText();
		 float j =  Float.parseFloat(i);
		 float k = b+j;
	       String l = Float.toString(k);
	       total.setText(l);
	}
	

	
	public void setItemDetailInTable() {
		String free = freetext.getText();
		Object row[]= new Object[20];
		
		
		row[0]= itemcombo.getSelectedItem().toString();
		row[1]= mfgtext.getText();
		row[2]= sachsntext.getText();
		if(free.isEmpty()) {
			row[3]= qtytext.getText();
		}else {
		row[3]= qtytext.getText() + "+"+freetext.getText();
		}
		row[4]= pricetext.getText();
		row[5]= taxtext.getText() ;
		row[6]= discounttext.getText() ;
		row[7]= total.getText();
		
		
		model_table.addRow(row);
		if(table.getRowCount() >10 ) {
			model_table.setRowCount(10);
		}
		itemcombo.requestFocus();
	}
	
	
	
	public void setAllFieldToZero() {
	
		sachsntext.setText("0");
		qtytext.setText("0");
		freetext.setText("0");
		pricetext.setText("0");
		taxtext.setText("0");
		taxablevalue.setText("0");
		taxratetext.setText("0");
		discounttext.setText("0");
		discounted.setText("0");
		cgstamount.setText("0");
		cgstrate.setText("0");
		utgstamount.setText("0");
		utgstrate.setText("0");
		total.setText("0");
		custadd1.setText(" ");
		custadd2.setText(" ");
		custmob.setText(" ");
	}
	
	
	public void IncreasingBillNo() {
		try {
			con = DriverManager.getConnection("jdbc:h2:C:/SimpleGST/GST","sa","");
			commonMethodForSt("select max(NO) from BILL_NO");
			
			while(rs.next()) {
				int billn = Integer.parseInt(rs.getString("max(NO)"));
				billn+=1;
				billnotext.setText(Integer.toString(billn));
			
			}
			
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void insertingBillNoIntoDatabase() {
		try {
			
		con = DriverManager.getConnection("jdbc:h2:C:/SimpleGST/GST","sa","");
		PreparedStatement ps = con.prepareStatement("insert into bill_no values(?)");
		ps.setString(1, billnotext.getText());
		ps.execute();
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	
	public void addingTotalAmountWithTax() {
		
		float total = 0;
		for(int i =0;i<table.getRowCount();i++) {
			
			float amount = Float.parseFloat((String)table.getValueAt(i, 7));
			total+=amount;
		}
		grandtotallabel.setText(String.valueOf(total));
	}
	
	public void addingTotalAmount() {
		float totalprice = 0;
		for(int i = 0; i<table.getRowCount();i++) {
			float totalamount = Float.parseFloat(table.getValueAt(i, 4).toString());
			totalprice+=totalamount;
		}
		
		totalamountlabel.setText(String.valueOf(totalprice));
	}
	
	
	
	public void deletingRow() {
		int i = table.getSelectedRow();
		if(i>=0) {
			model_table.removeRow(i);	
		}
		
		float total = 0;
		for(int i1 =0;i1<table.getRowCount();i1++) {
			
			float amount = Float.parseFloat((String)table.getValueAt(i1, 7));
			total+=amount;
		}
		grandtotallabel.setText(String.valueOf(total));
	}
	
	
	
	public void substractingStock() {
		String getstock = stocktext.getText();
		int s = Integer.parseInt(getstock);
		String getqty = qtytext.getText();
		int q = Integer.parseInt(getqty);
		int subtract = s-q;
		String free = freetext.getText();
		int fr = Integer.parseInt(free);
		int t = subtract-fr;
		String f = Integer.toString(t);
		stocktext.setText(f);
	}
	
	
	public void StockUpdate() {
		String fp = stocktext.getText();
		try {
			con =  DriverManager.getConnection("jdbc:h2:C:/SimpleGST/GST","sa","");
			String stock = itemcombo.getSelectedItem().toString();
			PreparedStatement us = con.prepareStatement("update additems set stock = '"+fp+"'where item_name ='"+stock+"'");
			
			us.execute();	
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
}
	
	public void outofstock() {
		String out = stocktext.getText();
		if(out.isEmpty()) {
			stocktext.setText("0");
		}
		int a = Integer.parseInt(out);
		if(a<=10) {
			label_1.setText("FILL STOCK");
		}else {
			label_1.setText(" ");
		}
		
	}
	
	
	public void setDate() {
		 DateFormat formatter = new SimpleDateFormat("dd_MMM_yyyy");
		 Date d = new Date();
		 datebox.setText(formatter.format(d));
	}
	
	public void setTime() {
		
		 DateFormat format = new SimpleDateFormat("hh:mm:ss");
		 Date t = new Date();
		 
		 timebox.setText(format.format(t));
		
	}

	
	public void setPaid() {
		
		String pd = paidtxt.getText();
		String tot = grandtotallabel.getText();
		
		if(pd.isEmpty()) {
			
			paidtxt.setText(tot);
			duetxt.setText("0");
			
		}
		
	}
	
	public void setDue() {
		String pd = paidtxt.getText();
		String tot = grandtotallabel.getText();
		if(pd.isEmpty()) {
			paidtxt.setText("0");
		}else {
		
		float a = Float.parseFloat(pd);
		float b = Float.parseFloat(tot);
		float c = b-a;
		
		String d = Float.toString(c);
		duetxt.setText(d);
		
		}
	}
	
	
	public void insertDueDetail() {
		String name = namecombo.getSelectedItem().toString().toUpperCase()+"_";
		String name1 = namecombo.getSelectedItem().toString();
		String bill = billnotext.getText()+"_";
		String date = datebox.getText().toUpperCase();
		String Gtot = grandtotallabel.getText();
		String paid = paidtxt.getText();
		String due = duetxt.getText();
		System.out.println(name+bill+date);
		float a = Float.parseFloat(due);
		
		if(a > 0) {
		 try {
			con =  DriverManager.getConnection("jdbc:h2:C:/SimpleGST/GST","sa","");
			String sql = "INSERT INTO DUES(Bill_No ,Date , Customer_name ,  Grand_Total , paid , Dues) VALUES ('"+name+bill+date+"' ,"
					+ "'"+date+"', "
							+ "'"+name1+"' ,"
									+ " '"+Gtot+"' , "
											+ "'"+paid+"' ,"
													+ "'"+due+"')";
			
			PreparedStatement ps = con.prepareStatement(sql);
			ps.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		
	}
	
	
	public Invoice()  {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(204,31,950,720);
		setUndecorated(true);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(240, 230, 140));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblName = new JLabel("Name           :");
		lblName.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblName.setBounds(22, 84, 86, 29);
		contentPane.add(lblName);
		
	    namecombo = new JComboBox();
	    namecombo.addKeyListener(new KeyAdapter() {
	    	@Override
	    	public void keyPressed(KeyEvent e) {
	    		if(e.getKeyCode()==KeyEvent.VK_ENTER) {
	    			itemcombo.requestFocus();
	    			namelbl.setText(namecombo.getSelectedItem().toString());
	    		}
	    	}
	    });
	    namecombo.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent arg0) {
	    		
	    		populateNameDetail();
	    	}
	    });
		namecombo.setBounds(135, 85, 272, 29);
		contentPane.add(namecombo);
		
		JLabel lblBillNo = new JLabel("Invoice No. :");
		lblBillNo.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblBillNo.setBounds(22, 123, 103, 27);
		contentPane.add(lblBillNo);
		
		billnotext = new JTextField();
		billnotext.setBackground(new Color(0, 0, 0));
		billnotext.setForeground(new Color(255, 255, 255));
		billnotext.setFont(new Font("Tahoma", Font.BOLD, 15));
		billnotext.setEditable(false);
		billnotext.setBounds(135, 124, 188, 29);
		contentPane.add(billnotext);
		billnotext.setColumns(10);
		
		JLabel lblDate = new JLabel("Date   :");
		lblDate.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblDate.setBounds(766, 95, 65, 21);
		contentPane.add(lblDate);
		
		datebox = new JTextField();
		datebox.setBackground(Color.BLACK);
		datebox.setForeground(Color.WHITE);
		datebox.setEditable(false);
		datebox.setBounds(833, 90, 86, 24);
		contentPane.add(datebox);
		datebox.setColumns(10);
		
	
		
		JSeparator separator = new JSeparator();
		separator.setBounds(0, 161, 950, 2);
		contentPane.add(separator);
		
		JLabel lblItemName = new JLabel("Item Name ");
		lblItemName.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblItemName.setBounds(22, 170, 73, 27);
		contentPane.add(lblItemName);
		
	    itemcombo = new JComboBox();
	    itemcombo.addKeyListener(new KeyAdapter() {
	    	@Override
	    	public void keyPressed(KeyEvent e) {
	    		if(e.getKeyCode()==KeyEvent.VK_ENTER) {
	    			qtytext.requestFocus();
	    		}
	    	}
	    });
	    itemcombo.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent arg0) {
               
	    		pricetext.setText("0");
                populateItemNameAndDetails();
	    		fillingAmountField();
	    		FillingRateField();
	    		
	    		
	    	}
	    });
		itemcombo.setBounds(22, 197, 366, 22);
		contentPane.add(itemcombo);
		
		
		sachsntext = new JTextField();
		sachsntext.setEditable(false);
		sachsntext.setHorizontalAlignment(SwingConstants.RIGHT);
		sachsntext.setBounds(410, 197, 86, 22);
		contentPane.add(sachsntext);
		sachsntext.setColumns(10);
		
		JLabel lblSachsnCode = new JLabel("SAC/HSN Code");
		lblSachsnCode.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblSachsnCode.setBounds(410, 177, 86, 14);
		contentPane.add(lblSachsnCode);
		
		qtytext = new JTextField();
		qtytext.setForeground(new Color(0, 0, 0));
		qtytext.setBorder(null);
		qtytext.setBackground(new Color(240, 230, 140));
		qtytext.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode()==KeyEvent.VK_ENTER) {

					calculatingTaxValue();
				updatingPriceAndTaxesAsQty();
				freetext.requestFocus();
				}
			}
		});
		qtytext.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent arg0) {
				updatingTotalAsPriceAndTax();
				qtytext.setBackground(new Color(240, 230, 140));
				qtytext.setForeground(Color.BLACK);
				
			}
			@Override
			public void focusGained(FocusEvent arg0) {
				qtytext.setBackground(Color.BLACK);
				qtytext.setForeground(Color.WHITE);
				qtytext.selectAll();
			}
		});
		
		qtytext.setHorizontalAlignment(SwingConstants.RIGHT);
		qtytext.setColumns(10);
		qtytext.setBounds(518, 197, 63, 22);
		contentPane.add(qtytext);
		
		JLabel lblQty = new JLabel("Qty");
		lblQty.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblQty.setBounds(535, 176, 46, 14);
		contentPane.add(lblQty);
		
		pricetext = new JTextField();
		pricetext.setEditable(false);
		pricetext.setHorizontalAlignment(SwingConstants.RIGHT);
		pricetext.setColumns(10);
		pricetext.setBounds(591, 197, 57, 22);
		contentPane.add(pricetext);
		
		taxtext = new JTextField();
		taxtext.setHorizontalAlignment(SwingConstants.RIGHT);
		taxtext.setEditable(false);
		taxtext.setColumns(10);
		taxtext.setBounds(742, 197, 86, 22);
		contentPane.add(taxtext);
		
		JLabel label = new JLabel("Price");
		label.setFont(new Font("Tahoma", Font.PLAIN, 13));
		label.setBounds(591, 176, 37, 14);
		contentPane.add(label);
		
		JLabel lblTax = new JLabel("Tax");
		lblTax.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblTax.setBounds(766, 176, 46, 14);
		contentPane.add(lblTax);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(22, 318, 918, 258);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(model_table);

		Object column_names[] = {"Item Name","Mfg", "Sac/Hsn", "Qty", "Price", "Tax(%)","Discount(%)","Total" }; 
		
		model_table.setColumnIdentifiers(column_names);

		
		final JButton btnPrint = new JButton("Print");
		btnPrint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setPaid();
				insertingBillNoIntoDatabase();
				CreateInvoiceTable op = new CreateInvoiceTable();
			//	op.invoicetable();
				//op.insertTempInv();
			//	insertDueDetail();
				
			
				try {
					Class.forName("org.h2.Driver");
					con  =  DriverManager.getConnection("jdbc:h2:C:/SimpleGST/GST","sa","");
					
					HashMap param = new HashMap();
					param.put("company_name", namecombo.getSelectedItem().toString());
					JasperDesign jd;
					jd = JRXmlLoader.load(new File("").getAbsoluteFile()+"/src/GSTls.jrxml");
					
					JasperReport jr = JasperCompileManager.compileReport(jd);
					@SuppressWarnings("unchecked")
					JasperPrint jp = JasperFillManager.fillReport(jr,param,con);
					JasperViewer jv = new JasperViewer(jp,false);
					jv.setVisible(true);
					
				} catch (SQLException | JRException | ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
	
		        setAllFieldToZero();
		        itemcombo.setSelectedIndex(0);
		        paidtxt.setText("0");
		        duetxt.setText("0");
		      //  IncreasingBillNo();
		    
		
	  
			}
		});
		btnPrint.setBounds(817, 674, 89, 23);
		contentPane.add(btnPrint);
		
		discounttext = new JTextField();
		discounttext.setBackground(new Color(240, 230, 140));
		discounttext.setBorder(null);
		discounttext.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent arg0) {
				discounttext.setBackground(Color.BLACK);
				discounttext.setForeground(Color.WHITE);
				discounttext.selectAll();
				freetext.cut();

			}
			@Override
			public void focusLost(FocusEvent arg0) {
				discounttext.setBackground(new Color(240, 230, 140));
				discounttext.setForeground(Color.BLACK);
			}
		});
		
		discounttext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Discount();
				
				
				if(qtytext.getText().equals("0")) {
					qtytext.requestFocus();
				}else {
				
					btnAdd.requestFocus();
				
			      }
			  }
		});
		discounttext.setHorizontalAlignment(SwingConstants.RIGHT);
		discounttext.setBounds(854, 199, 86, 20);
		contentPane.add(discounttext);
		discounttext.setColumns(10);
		
		JLabel lblDiscount = new JLabel("Discount (%)");
		lblDiscount.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblDiscount.setBounds(854, 177, 86, 14);
		contentPane.add(lblDiscount);
		
		JLabel lblTaxRate = new JLabel("Tax Rate");
		lblTaxRate.setBounds(22, 230, 46, 20);
		contentPane.add(lblTaxRate);
		
		JLabel lblCgstRate = new JLabel("CGST Rate");
		lblCgstRate.setBounds(225, 232, 65, 20);
		contentPane.add(lblCgstRate);
		
		JLabel lblSutgstRate = new JLabel("S/UTGST Rate");
		lblSutgstRate.setBounds(426, 231, 86, 14);
		contentPane.add(lblSutgstRate);
		
		utgstrate = new JTextField();
		utgstrate.setHorizontalAlignment(SwingConstants.RIGHT);
		utgstrate.setEditable(false);
		utgstrate.setColumns(10);
		utgstrate.setBounds(518, 228, 86, 22);
		contentPane.add(utgstrate);
		
		JLabel lblTaxableValue = new JLabel("Taxable Value");
		lblTaxableValue.setBounds(22, 252, 73, 23);
		contentPane.add(lblTaxableValue);
		
		taxablevalue = new JTextField();
		taxablevalue.setHorizontalAlignment(SwingConstants.RIGHT);
		taxablevalue.setEditable(false);
		taxablevalue.setColumns(10);
		taxablevalue.setBounds(112, 253, 86, 22);
		contentPane.add(taxablevalue);
		
		taxratetext = new JTextField();
		taxratetext.setHorizontalAlignment(SwingConstants.RIGHT);
		taxratetext.setEditable(false);
		taxratetext.setColumns(10);
		taxratetext.setBounds(112, 230, 86, 22);
		contentPane.add(taxratetext);
		
		cgstrate = new JTextField();
		cgstrate.setHorizontalAlignment(SwingConstants.RIGHT);
		cgstrate.setEditable(false);
		cgstrate.setColumns(10);
		cgstrate.setBounds(304, 231, 86, 22);
		contentPane.add(cgstrate);
		
		JLabel lblCgstAmount = new JLabel("CGST Amount");
		lblCgstAmount.setBounds(225, 258, 80, 20);
		contentPane.add(lblCgstAmount);
		
		cgstamount = new JTextField();
		cgstamount.setHorizontalAlignment(SwingConstants.RIGHT);
		cgstamount.setEditable(false);
		cgstamount.setColumns(10);
		cgstamount.setBounds(304, 255, 86, 22);
		contentPane.add(cgstamount);
		
		JLabel lblSutgstAmount = new JLabel("S/UTGST Amount");
		lblSutgstAmount.setBounds(422, 256, 86, 14);
		contentPane.add(lblSutgstAmount);
		
		utgstamount = new JTextField();
		utgstamount.setHorizontalAlignment(SwingConstants.RIGHT);
		utgstamount.setEditable(false);
		utgstamount.setColumns(10);
		utgstamount.setBounds(518, 253, 86, 22);
		contentPane.add(utgstamount);
		
		JLabel lblTotalAmount = new JLabel("Total Amount        :");
		lblTotalAmount.setBounds(747, 587, 102, 14);
		contentPane.add(lblTotalAmount);
		
		totalamountlabel = new JLabel("0.0");
		totalamountlabel.setBounds(859, 587, 81, 14);
		contentPane.add(totalamountlabel);
		
		JLabel lblGrandTotal = new JLabel("Grand Total           :");
		lblGrandTotal.setForeground(new Color(0, 51, 204));
		lblGrandTotal.setBounds(747, 606, 102, 14);
		contentPane.add(lblGrandTotal);
		
		grandtotallabel = new JLabel("0.0");
		grandtotallabel.setForeground(new Color(0, 51, 255));
		grandtotallabel.setBounds(859, 606, 81, 14);
		contentPane.add(grandtotallabel);
		
		 custadd1 = new JLabel("");
		 custadd1.setBackground(new Color(240,240,240));
		custadd1.setBounds(425, 41, 331, 21);
		contentPane.add(custadd1);
		
		custmob = new JLabel("");
		custmob.setBounds(425, 92, 331, 21);
		contentPane.add(custmob);
		
		custadd2 = new JLabel("");
		custadd2.setBounds(426, 67, 330, 21);
		contentPane.add(custadd2);
		
		discounted = new JTextField();
		discounted.setEditable(false);
		discounted.setHorizontalAlignment(SwingConstants.RIGHT);
		discounted.setColumns(10);
		discounted.setBounds(304, 287, 86, 20);
		contentPane.add(discounted);
		
		total = new JTextField();
		total.setHorizontalAlignment(SwingConstants.RIGHT);
		total.setEditable(false);
		total.setColumns(10);
		total.setBounds(112, 285, 86, 22);
		contentPane.add(total);
		
		JLabel lblTotal = new JLabel("Total");
		lblTotal.setBounds(22, 286, 46, 21);
		contentPane.add(lblTotal);
		
		p1 = new JLabel("");
		p1.setForeground(new Color(240, 230, 140));
		p1.setBounds(631, 177, 10, 14);
		contentPane.add(p1);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				deletingRow();
				addingTotalAmount();
					
				
			}
		});
		btnDelete.setBounds(36, 597, 89, 23);
		contentPane.add(btnDelete);
		
		JLabel lblStock = new JLabel("Stock");
		lblStock.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblStock.setBounds(684, 230, 46, 21);
		contentPane.add(lblStock);
		
		stocktext = new JTextField();
		stocktext.setHorizontalAlignment(SwingConstants.RIGHT);
		stocktext.setEditable(false);
		stocktext.setColumns(10);
		stocktext.setBounds(742, 232, 86, 22);
		contentPane.add(stocktext);
		
        btnAdd = new JButton("");
        btnAdd.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyPressed(KeyEvent arg0) {
        		setItemDetailInTable();
				addingTotalAmountWithTax();
				addingTotalAmount();
				StockUpdate();
        	}
        });
        btnAdd.setOpaque(false);
        btnAdd.setBorder(null);
		btnAdd.setBounds(851, 295, 89, 23);
		contentPane.add(btnAdd);
		
		lblMfg = new JLabel("Mfg");
		lblMfg.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblMfg.setBounds(684, 261, 46, 17);
		contentPane.add(lblMfg);
		
		mfgtext = new JTextField();
		mfgtext.setHorizontalAlignment(SwingConstants.LEFT);
		mfgtext.setEditable(false);
		mfgtext.setColumns(10);
		mfgtext.setBounds(742, 258, 198, 22);
		contentPane.add(mfgtext);
		
		lblDiscountAmt = new JLabel("Discount Amt.");
		lblDiscountAmt.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblDiscountAmt.setBounds(225, 289, 80, 18);
		contentPane.add(lblDiscountAmt);
		
		label_1 = new JLabel("");
		label_1.setForeground(Color.RED);
		label_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		label_1.setBounds(844, 230, 96, 22);
		contentPane.add(label_1);
		
		lblFree = new JLabel("Free");
		lblFree.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblFree.setBounds(679, 174, 46, 14);
		contentPane.add(lblFree);
		
		freetext = new JTextField();
		freetext.setOpaque(false);
		freetext.setBorder(null);
		freetext.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent arg0) {
				substractingStock();
				outofstock();
				freetext.setOpaque(false);
			
				freetext.setForeground(Color.black);
			}
			@Override
			public void focusGained(FocusEvent arg0) {
				freetext.selectAll();
				freetext.setOpaque(true);
				freetext.setBackground(Color.BLACK);
				freetext.setForeground(Color.WHITE);
			}
		});
		freetext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				discounttext.requestFocus();
			}
		});
		freetext.setHorizontalAlignment(SwingConstants.RIGHT);
		freetext.setColumns(10);
		freetext.setBounds(668, 195, 57, 22);
		contentPane.add(freetext);
		
		JLabel lblTime = new JLabel("Time   :");
		lblTime.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblTime.setBounds(766, 126, 65, 21);
		contentPane.add(lblTime);
		
		timebox = new JTextField();
		timebox.setForeground(Color.WHITE);
		timebox.setEditable(false);
		timebox.setColumns(10);
		timebox.setBackground(Color.BLACK);
		timebox.setBounds(833, 126, 86, 24);
		contentPane.add(timebox);
		
		 namelbl = new JLabel("");
		namelbl.setBounds(166, 60, 139, 14);
		contentPane.add(namelbl);
		
		paidtxt = new JTextField();
		
		paidtxt.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent arg0) {
				paidtxt.selectAll();
			}
		});
		paidtxt.setHorizontalAlignment(SwingConstants.RIGHT);
		paidtxt.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode()==KeyEvent.VK_ENTER) {
					setDue();
					btnPrint.requestFocus();
				}
			}
		});
		paidtxt.setBounds(488, 603, 86, 20);
		contentPane.add(paidtxt);
		paidtxt.setColumns(10);
		
		duetxt = new JTextField();
		duetxt.setEditable(false);
		duetxt.setHorizontalAlignment(SwingConstants.RIGHT);
		duetxt.setColumns(10);
		duetxt.setBounds(593, 603, 86, 20);
		contentPane.add(duetxt);
		
		JLabel lblPaid = new JLabel("Paid");
		lblPaid.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblPaid.setBounds(518, 586, 37, 14);
		contentPane.add(lblPaid);
		
		JLabel lblDue = new JLabel("Due");
		lblDue.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblDue.setBounds(623, 587, 37, 14);
		contentPane.add(lblDue);
		
		 custGstin = new JLabel("");
		custGstin.setBounds(425, 118, 331, 21);
		contentPane.add(custGstin);
		
		populatename();
		populateItemCombo();
		FillingRateField();
		IncreasingBillNo();
		setDate();
		setTime();
		String a = namelbl.getText();
		if(a.isEmpty()) {
			namelbl.setText("a");
		}else {
			namelbl.setText(namecombo.getSelectedItem().toString());
		}
	
		
	}
}
