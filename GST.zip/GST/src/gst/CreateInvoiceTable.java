package gst;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;

import javax.swing.table.DefaultTableModel;

import com.jtattoo.plaf.graphite.GraphiteLookAndFeel;

public class CreateInvoiceTable  {
	
	Connection con = null;
	Statement st;
	
	public String bill = Invoice.billnotext.getText()+"_";
    public String name = Invoice.namecombo.getSelectedItem().toString()+"_";
    public String bill1 = Invoice.billnotext.getText();
    public String name1 = Invoice.namecombo.getSelectedItem().toString();
    public String date = Invoice.datebox.getText();
    public String grandt = Invoice.grandtotallabel.getText();
    public String pd = Invoice.paidtxt.getText();
    public String du =Invoice.duetxt.getText();
	
	public void invoicetable() {
		
	    
	  System.out.println(name+bill+date);
	    
	try {
			con =  DriverManager.getConnection("jdbc:h2:C:/SimpleGST/GST/INVOICES","sa","");
			 st = con.createStatement();
		
		String sql = "CREATE TABLE "+name+bill+date+""
				+ "(Bill_no varchar(255),"
				+ "Date varchar(255),"
				+ "Customer_Name varchar(255),"
				+ "Item_Name varchar(255),"
				+ "mfg varchar(255),"
				+ "sac_hsn INT(255),"
				+ "Qty INT(255),"
				+ "Price FLOAT(255),"
				+ "Tax INT(255),"                         
				+ "Discount FLOAT(255),"
	            + "Total FLOAT(255),"		
				+ "Grand_Total varchar(255),"
				+ "paid FLOAT(255),"
				+ "DUE FLOAT(255))";
			
			st.execute(sql);
			String a = "INSERT INTO "+name+bill+date+"(Bill_no , Date ,  Customer_Name ) values('"+bill1+"','"+date+"','"+name1+"')";
			st.execute(a);
			
			DefaultTableModel mt = (DefaultTableModel)Invoice.table.getModel();
			for(int i = 0 ; i<Invoice.table.getRowCount(); i++) {
				String item = (String) Invoice.table.getValueAt(i, 0);
				String mfg = (String) Invoice.table.getValueAt(i, 1);
				String sac = (String) Invoice.table.getValueAt(i, 2);
				String qty = (String) Invoice.table.getValueAt(i, 3);
				String price = (String) Invoice.table.getValueAt(i, 4);
				String tax = (String) Invoice.table.getValueAt(i, 5);
				String discount = (String) Invoice.table.getValueAt(i, 6);
				String total = (String) Invoice.table.getValueAt(i, 7);
				
				String b = "INSERT INTO "+name+bill+date+"(Item_Name, mfg, sac_hsn,  Qty, Price, Tax, Discount,Total) values('"+item+"',"
						+ "'"+mfg+"',"
								+ "'"+sac+"',"
										+ "'"+qty+"',"
												+ "'"+price+"',"
														+ "'"+tax+"',"
																+ "'"+discount+"',"
																		+ "'"+total+"')";
				st.execute(b);
			}
			
			
			
		String c ="INSERT INTO "+name+bill+date+"(Grand_Total , paid , due ) VALUES('"+grandt+"','"+pd+"','"+du+"')";
		st.execute(c);
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		}
	
	}
	
	public void insertTempInv()
	{
		
		try {
			con =  DriverManager.getConnection("jdbc:h2:C:/SimpleGST/GST","sa","");
			 st = con.createStatement();
				DefaultTableModel mt = (DefaultTableModel)Invoice.table.getModel();
				for(int i = 0 ; i<Invoice.table.getRowCount(); i++) {
					String item = (String) Invoice.table.getValueAt(i, 0);
					String mfg = (String) Invoice.table.getValueAt(i, 1);
					String sac = (String) Invoice.table.getValueAt(i, 2);
					String qty = (String) Invoice.table.getValueAt(i, 3);
					String price = (String) Invoice.table.getValueAt(i, 4);
					String tax = (String) Invoice.table.getValueAt(i, 5);
					String discount = (String) Invoice.table.getValueAt(i, 6);
					String total = (String) Invoice.table.getValueAt(i, 7);
					
					String bd = "INSERT INTO tempinv(Item_Name, mfg, sac_hsn,  Qty, Price, Tax, Discount,Total) values('"+item+"',"
							+ "'"+mfg+"',"
									+ "'"+sac+"',"
											+ "'"+qty+"',"
													+ "'"+price+"',"
															+ "'"+tax+"',"
																	+ "'"+discount+"',"
																			+ "'"+total+"')";
					
					st.execute(bd);
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	
	public void deleteTempInv() {
		try {
			con =  DriverManager.getConnection("jdbc:h2:C:/SimpleGST/GST","sa","");
			 st = con.createStatement();
			 
			 String del = "DROP TABLE TEMPINV";
			 st.executeUpdate(del);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
		

	
	public void createTempTable() {
		
		try {
			con =  DriverManager.getConnection("jdbc:h2:C:/SimpleGST/GST","sa","");
			 st = con.createStatement();
			 String tempinv = "CREATE TABLE TEMPINV"
				 		+ "(Sr int auto_increment,"
				 		+ "ITEM_NAME VARCHAR(255),"
				 		+ "MFG VARCHAR(255),"
				 		+ "SAC_HSN INT(255),"
				 		+ "QTY INT(255),"
				 		+ "PRICE FLOAT(255),"
				 		+ "TAX INT(255),"
				 		+ "DISC FLOAT(255),"
				 		+ "TOTAL FLOAT(255))";
				 
				 st.execute(tempinv);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
			 
	}


	
	
	}

