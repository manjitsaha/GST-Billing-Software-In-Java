package gst;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class CreatingTableAndPreData {
	
	static Connection con =null;
	static Statement st =null;
	static ResultSet rs = null;
	
	public void createDetails() {
		try {
			
			//items table
			
			 con=DriverManager.getConnection("jdbc:h2:C:/SimpleGST/GST","sa","");
			 st = con.createStatement();
			 /*		String q = "CREATE TABLE additems"
					+ "(item_name VARCHAR(255),"
					+ "manufacturer varchar(255),"
					+ "sac_hsn VARCHAR(255),"
					+ "unit varchar(255),"
					+ "sale_rmate varchar(255),"
					+ "purchase_rate VARCHAR(255),"
					+ "Tax varchar(6),"
					+ "stock VARCHAR(255),"
					+ "description VARCHAR(255),"
					+ "remarks VARCHAR(255))";
			st.execute(q);
			
			
			//company table
			
			String c = "CREATE TABLE company"
					+ "(company_name VARCHAR(255),"
					+ "trade_name VARCHAR(255),"
					+ "add_1 VARCHAR(255),"
					+ "add_2 VARCHAR(255),"
					+ "state VARCHAR(255),"
					+ "place VARCHAR(255),"
					+ "pin VARCHAR(255),"
					+ "email_id VARCHAR(255),"
					+ "website VARCHAR(255),"
					+ "mobile_no VARCHAR(255),"
					+ "establishment_date VARCHAR(255),"
					+ "gst_number VARCHAR(255),"
					+ "gst_date VARCHAR(255),"
					+ "gst_category VARCHAR(255),"
					+ "pan VARCHAR(255),"
					+ "pan_date VARCHAR(255),"
					+ "tan VARCHAR(255),"
					+ "tan_date VARCHAR(255))";
			
			st.execute(c);
			
			//Adding default states
			
		String s = "CREATE TABLE states"
				+ "(States varchar(25),"
				+ "states_code varchar(3))";
		st.execute(s);	
		
		// Inserting states into table
		
		String an ="insert into states values ('Andaman and Nicobar Islands','35')";
		String ap ="insert into states values ('Andhra Pradesh'	,'28')";
		String apn ="insert into states values('Andhra Pradesh New','37')";
		String anp ="insert into states values ('Arunachal Pradesh','12')";
		String as ="insert into states values ('Assam','18')";
		String br ="insert into states values ('Bihar','10')";
		String ch ="insert into states values ('Chandigarh','04')";
		String chtg ="insert into states values ('Chattisgarh','22')";
		String dnnh ="insert into states values ('Dadra and Nagar Haveli','26')";
		String dnd ="insert into states values ('Daman and Diu','25')";
		String dl ="insert into states values ('Delhi','7')";
		String goa ="insert into states values ('Goa','30')";
		String gj ="insert into states values ('Gujarat','24')";
		String hr ="insert into states values ('Haryana','6')";
		String hp ="insert into states values ('Himachal Pradesh','2')";
		String jk ="insert into states values ('Jammu and Kashmir','1')";
		String jh ="insert into states values ('Jharkhand','20')";
		String kr ="insert into states values ('Karnataka','29')";
		String ke ="insert into states values ('Kerla','32')";
		String ldi ="insert into states values ('Lakshadweep Islands','31')";
		String mp ="insert into states values ('Madhya Pradesh','23')";
		String mh ="insert into states values ('Maharashtra','27')";
		String mani ="insert into states values ('Manipur','14')";
		String mg ="insert into states values ('Meghalaya','17')";
		String mz ="insert into states values ('Mizoram','15')";
		String ng ="insert into states values ('Nagaland','13')";
		String od ="insert into states values ('Odisha','21')";
		String pd ="insert into states values ('Pondicherry','34')";
		String pj ="insert into states values ('Punjab','3')";
		String rj ="insert into states values ('Rajasthan','8')";
		String sk ="insert into states values ('Sikkim','11')";
		String tn ="insert into states values ('Tamil Nadu','33')";
		String tg ="insert into states values ('Telangana','36')";
		String tr ="insert into states values ('Tripura','16')";
		String up ="insert into states values ('Uttar Pradesh','9')";
		String uk ="insert into states values ('Uttarakhand','5')";
		String wb ="insert into states values ('West Bengal','19')";


		
			
			
		
			st.execute(an);
			st.execute(ap);
			st.execute(apn);
			st.execute(anp);
			st.execute(as);
			st.execute(br);
			st.execute(ch);
			st.execute(chtg);
			st.execute(dnnh);
			st.execute(dnd);
			st.execute(dl);
			st.execute(goa);
			st.execute(gj);
			st.execute(hr);
			st.execute(hp);
			st.execute(jk);
			st.execute(jh);
			st.execute(kr);
			st.execute(ke);
			st.execute(ldi);
			st.execute(mp);
			st.execute(mh);
			st.execute(mani);
			st.execute(mg);
			st.execute(mz);
			st.execute(ng);
			st.execute(od);
			st.execute(pd);
			st.execute(pj);
			st.execute(rj);
			st.execute(sk);
			st.execute(tn);
			st.execute(tg);
			st.execute(tr);
			st.execute(up);
			st.execute(uk);
			st.execute(wb);
			
			
			
			// Create customer table
			
			String com = "CREATE TABLE CUSTOMERS"
					+ "(NAME varchar(25),"
					+ "place varchar(25),"
					+ "state varchar(50),"
					+ "email varchar(100),"
					+ "add1 varchar(100),"
					+ "add2 varchar(100),"
					+ "pin varchar(10),"
					+ "website varchar(50),"
					+ "mob_no varchar(20),"
					+ "alt_mob varchar(20),"
					+ "fax varchar(14),"
					+ "phone varchar(10),"
					+ "gst varchar(16),"
					+ "pan varchar(16),"
					+ "pan_Date varchar(10),"
					+ "ledger_category varchar(10),"
					+ "country varchar(20))";
		
			st.execute(com);			
		
		
			
			// CREATE INVOICE NO
			
			String billno = "CREATE TABLE BILL_NO"
					+ "(NO varchar(225))";
			
			// ADMIN PANEL
			
			String user = "CREATE TABLE ADMIN"
					+ "(USERNAME VARCHAR(255),"
					+ "PASSWORD VARCHAR(255))";
			
			String def = "INSERT INTO ADMIN VALUES('admin','password')";
			
			st.execute(user);
			st.execute(def);
			
			// CREATE DUE TABLE
			
					
			String due = "CREATE TABLE DUES"
					+ "(Bill_No varchar(255),"
					+ "Date varchar(255),"
					+ "Customer_name varchar(255),"
					+ "Grand_Total float(255),"
					+ "paid float(255),"
					+ "Dues float(255))";
			
					st.execute(due);
			
			*/
			 
			 String tempinv = "CREATE TABLE TEMPINV"
			 		+ "(Sr int auto_increment,"
			 		+ "ITEM_NAME VARCHAR(255),"
			 		+ "MFG VARCHAR(255),"
			 		+ "SAC_HSN INT(255),"
			 		+ "QTY INT(255),"
			 		+ "PRICE FLOAT(255),"
			 		+ "TAX INT(255),"
			 		+ "DISC FLOAT(255),"
			 		+ "TOTAL FLOAT(255))";
			 
			 st.execute(tempinv);
			 		
					 
	
			
			System.out.println("table added successfully"); 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				con.close();
			}catch(Exception e1) {
			
			}
		}
		
		
			
				
				
	}

}
