package gst;

import java.awt.Color;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

public class Stockm extends JFrame {

	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	JScrollPane scrollPane;

	/**
	 * Launch the application.
	 */
	
	
	
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Stockm frame = new Stockm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
		}

	/**
	 * Create the frame.
	 */
	Connection con = null;
	PreparedStatement st;
	ResultSet rs;
	
	public void stock() {
		try {
		    con = DriverManager.getConnection("jdbc:h2:C:/SimpleGST/GST","sa","");
			String stk = "SELECT ITEM_NAME , STOCK FROM ADDITEMS ORDER BY ITEM_NAME ASC";
			 st = con.prepareStatement(stk);
			 rs = st.executeQuery();
			
		//	while(rs.next()){
				table.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
		//	}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		}
	}
	
	public Stockm() {
		addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent arg0) {
				dispose();
			}
		});
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(204,31,973,700);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(240, 230, 140));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setUndecorated(true);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 0, 973, 700);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		stock();
		

	}
}
